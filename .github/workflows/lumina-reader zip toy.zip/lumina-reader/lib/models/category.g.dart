// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'category.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetCategoryCollection on Isar {
  IsarCollection<Category> get categorys => this.collection();
}

const CategorySchema = CollectionSchema(
  name: r'Category',
  id: 5751694338128944171,
  properties: {
    r'autoDownload': PropertySchema(
      id: 0,
      name: r'autoDownload',
      type: IsarType.bool,
    ),
    r'autoDownloadCount': PropertySchema(
      id: 1,
      name: r'autoDownloadCount',
      type: IsarType.long,
    ),
    r'color': PropertySchema(
      id: 2,
      name: r'color',
      type: IsarType.string,
    ),
    r'createdAt': PropertySchema(
      id: 3,
      name: r'createdAt',
      type: IsarType.long,
    ),
    r'description': PropertySchema(
      id: 4,
      name: r'description',
      type: IsarType.string,
    ),
    r'displayMode': PropertySchema(
      id: 5,
      name: r'displayMode',
      type: IsarType.string,
      enumMap: _CategorydisplayModeEnumValueMap,
    ),
    r'downloadedCount': PropertySchema(
      id: 6,
      name: r'downloadedCount',
      type: IsarType.long,
    ),
    r'entryCount': PropertySchema(
      id: 7,
      name: r'entryCount',
      type: IsarType.long,
    ),
    r'filterSourceIds': PropertySchema(
      id: 8,
      name: r'filterSourceIds',
      type: IsarType.stringList,
    ),
    r'filterStatuses': PropertySchema(
      id: 9,
      name: r'filterStatuses',
      type: IsarType.longList,
    ),
    r'filterTags': PropertySchema(
      id: 10,
      name: r'filterTags',
      type: IsarType.stringList,
    ),
    r'hideReadEntries': PropertySchema(
      id: 11,
      name: r'hideReadEntries',
      type: IsarType.bool,
    ),
    r'icon': PropertySchema(
      id: 12,
      name: r'icon',
      type: IsarType.string,
    ),
    r'isDefault': PropertySchema(
      id: 13,
      name: r'isDefault',
      type: IsarType.bool,
    ),
    r'isDefaultIndex': PropertySchema(
      id: 14,
      name: r'isDefaultIndex',
      type: IsarType.bool,
    ),
    r'isHidden': PropertySchema(
      id: 15,
      name: r'isHidden',
      type: IsarType.bool,
    ),
    r'isHiddenIndex': PropertySchema(
      id: 16,
      name: r'isHiddenIndex',
      type: IsarType.bool,
    ),
    r'isLocked': PropertySchema(
      id: 17,
      name: r'isLocked',
      type: IsarType.bool,
    ),
    r'isSmart': PropertySchema(
      id: 18,
      name: r'isSmart',
      type: IsarType.bool,
    ),
    r'isSmartIndex': PropertySchema(
      id: 19,
      name: r'isSmartIndex',
      type: IsarType.bool,
    ),
    r'name': PropertySchema(
      id: 20,
      name: r'name',
      type: IsarType.string,
    ),
    r'nameIndex': PropertySchema(
      id: 21,
      name: r'nameIndex',
      type: IsarType.string,
    ),
    r'nameTypeIndex': PropertySchema(
      id: 22,
      name: r'nameTypeIndex',
      type: IsarType.string,
    ),
    r'newCount': PropertySchema(
      id: 23,
      name: r'newCount',
      type: IsarType.long,
    ),
    r'position': PropertySchema(
      id: 24,
      name: r'position',
      type: IsarType.long,
    ),
    r'positionIndex': PropertySchema(
      id: 25,
      name: r'positionIndex',
      type: IsarType.long,
    ),
    r'showCount': PropertySchema(
      id: 26,
      name: r'showCount',
      type: IsarType.bool,
    ),
    r'showDownloadBadge': PropertySchema(
      id: 27,
      name: r'showDownloadBadge',
      type: IsarType.bool,
    ),
    r'showNewBadge': PropertySchema(
      id: 28,
      name: r'showNewBadge',
      type: IsarType.bool,
    ),
    r'smartQuery': PropertySchema(
      id: 29,
      name: r'smartQuery',
      type: IsarType.string,
    ),
    r'sortAscending': PropertySchema(
      id: 30,
      name: r'sortAscending',
      type: IsarType.bool,
    ),
    r'sortByLastRead': PropertySchema(
      id: 31,
      name: r'sortByLastRead',
      type: IsarType.bool,
    ),
    r'type': PropertySchema(
      id: 32,
      name: r'type',
      type: IsarType.string,
      enumMap: _CategorytypeEnumValueMap,
    ),
    r'typeIndex': PropertySchema(
      id: 33,
      name: r'typeIndex',
      type: IsarType.string,
      enumMap: _CategorytypeIndexEnumValueMap,
    ),
    r'unreadCount': PropertySchema(
      id: 34,
      name: r'unreadCount',
      type: IsarType.long,
    ),
    r'updatedAt': PropertySchema(
      id: 35,
      name: r'updatedAt',
      type: IsarType.long,
    )
  },
  estimateSize: _categoryEstimateSize,
  serialize: _categorySerialize,
  deserialize: _categoryDeserialize,
  deserializeProp: _categoryDeserializeProp,
  idName: r'id',
  indexes: {
    r'nameIndex': IndexSchema(
      id: 1719013866778217298,
      name: r'nameIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'nameIndex',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    ),
    r'nameTypeIndex_type': IndexSchema(
      id: -2966739451264843543,
      name: r'nameTypeIndex_type',
      unique: true,
      replace: true,
      properties: [
        IndexPropertySchema(
          name: r'nameTypeIndex',
          type: IndexType.hash,
          caseSensitive: true,
        ),
        IndexPropertySchema(
          name: r'type',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    ),
    r'positionIndex': IndexSchema(
      id: -7285304985504923386,
      name: r'positionIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'positionIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'typeIndex': IndexSchema(
      id: 259437455522897078,
      name: r'typeIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'typeIndex',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    ),
    r'isDefaultIndex': IndexSchema(
      id: -6108570210045271476,
      name: r'isDefaultIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'isDefaultIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'isHiddenIndex': IndexSchema(
      id: 4458629484526198896,
      name: r'isHiddenIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'isHiddenIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'isSmartIndex': IndexSchema(
      id: -2618596100490240615,
      name: r'isSmartIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'isSmartIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    )
  },
  links: {
    r'source': LinkSchema(
      id: -5445046225681233401,
      name: r'source',
      target: r'Source',
      single: false,
    )
  },
  embeddedSchemas: {},
  getId: _categoryGetId,
  getLinks: _categoryGetLinks,
  attach: _categoryAttach,
  version: '3.1.0+1',
);

int _categoryEstimateSize(
  Category object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  {
    final value = object.color;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.description;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.displayMode;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final list = object.filterSourceIds;
    if (list != null) {
      bytesCount += 3 + list.length * 3;
      {
        for (var i = 0; i < list.length; i++) {
          final value = list[i];
          bytesCount += value.length * 3;
        }
      }
    }
  }
  {
    final value = object.filterStatuses;
    if (value != null) {
      bytesCount += 3 + value.length * 8;
    }
  }
  {
    final list = object.filterTags;
    if (list != null) {
      bytesCount += 3 + list.length * 3;
      {
        for (var i = 0; i < list.length; i++) {
          final value = list[i];
          bytesCount += value.length * 3;
        }
      }
    }
  }
  {
    final value = object.icon;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  bytesCount += 3 + object.name.length * 3;
  bytesCount += 3 + object.nameIndex.length * 3;
  bytesCount += 3 + object.nameTypeIndex.length * 3;
  {
    final value = object.smartQuery;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.type;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.typeIndex;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  return bytesCount;
}

void _categorySerialize(
  Category object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeBool(offsets[0], object.autoDownload);
  writer.writeLong(offsets[1], object.autoDownloadCount);
  writer.writeString(offsets[2], object.color);
  writer.writeLong(offsets[3], object.createdAt);
  writer.writeString(offsets[4], object.description);
  writer.writeString(offsets[5], object.displayMode?.name);
  writer.writeLong(offsets[6], object.downloadedCount);
  writer.writeLong(offsets[7], object.entryCount);
  writer.writeStringList(offsets[8], object.filterSourceIds);
  writer.writeLongList(offsets[9], object.filterStatuses);
  writer.writeStringList(offsets[10], object.filterTags);
  writer.writeBool(offsets[11], object.hideReadEntries);
  writer.writeString(offsets[12], object.icon);
  writer.writeBool(offsets[13], object.isDefault);
  writer.writeBool(offsets[14], object.isDefaultIndex);
  writer.writeBool(offsets[15], object.isHidden);
  writer.writeBool(offsets[16], object.isHiddenIndex);
  writer.writeBool(offsets[17], object.isLocked);
  writer.writeBool(offsets[18], object.isSmart);
  writer.writeBool(offsets[19], object.isSmartIndex);
  writer.writeString(offsets[20], object.name);
  writer.writeString(offsets[21], object.nameIndex);
  writer.writeString(offsets[22], object.nameTypeIndex);
  writer.writeLong(offsets[23], object.newCount);
  writer.writeLong(offsets[24], object.position);
  writer.writeLong(offsets[25], object.positionIndex);
  writer.writeBool(offsets[26], object.showCount);
  writer.writeBool(offsets[27], object.showDownloadBadge);
  writer.writeBool(offsets[28], object.showNewBadge);
  writer.writeString(offsets[29], object.smartQuery);
  writer.writeBool(offsets[30], object.sortAscending);
  writer.writeBool(offsets[31], object.sortByLastRead);
  writer.writeString(offsets[32], object.type?.name);
  writer.writeString(offsets[33], object.typeIndex?.name);
  writer.writeLong(offsets[34], object.unreadCount);
  writer.writeLong(offsets[35], object.updatedAt);
}

Category _categoryDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = Category(
    autoDownload: reader.readBoolOrNull(offsets[0]),
    autoDownloadCount: reader.readLongOrNull(offsets[1]),
    color: reader.readStringOrNull(offsets[2]),
    createdAt: reader.readLongOrNull(offsets[3]),
    description: reader.readStringOrNull(offsets[4]),
    displayMode:
        _CategorydisplayModeValueEnumMap[reader.readStringOrNull(offsets[5])],
    downloadedCount: reader.readLongOrNull(offsets[6]),
    entryCount: reader.readLongOrNull(offsets[7]),
    filterSourceIds: reader.readStringList(offsets[8]),
    filterStatuses: reader.readLongList(offsets[9]),
    filterTags: reader.readStringList(offsets[10]),
    hideReadEntries: reader.readBoolOrNull(offsets[11]),
    icon: reader.readStringOrNull(offsets[12]),
    id: id,
    isDefault: reader.readBoolOrNull(offsets[13]),
    isHidden: reader.readBoolOrNull(offsets[15]),
    isLocked: reader.readBoolOrNull(offsets[17]),
    isSmart: reader.readBoolOrNull(offsets[18]),
    name: reader.readString(offsets[20]),
    newCount: reader.readLongOrNull(offsets[23]),
    position: reader.readLongOrNull(offsets[24]),
    showCount: reader.readBoolOrNull(offsets[26]),
    showDownloadBadge: reader.readBoolOrNull(offsets[27]),
    showNewBadge: reader.readBoolOrNull(offsets[28]),
    smartQuery: reader.readStringOrNull(offsets[29]),
    sortAscending: reader.readBoolOrNull(offsets[30]),
    sortByLastRead: reader.readBoolOrNull(offsets[31]),
    type: _CategorytypeValueEnumMap[reader.readStringOrNull(offsets[32])],
    unreadCount: reader.readLongOrNull(offsets[34]),
    updatedAt: reader.readLongOrNull(offsets[35]),
  );
  return object;
}

P _categoryDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readBoolOrNull(offset)) as P;
    case 1:
      return (reader.readLongOrNull(offset)) as P;
    case 2:
      return (reader.readStringOrNull(offset)) as P;
    case 3:
      return (reader.readLongOrNull(offset)) as P;
    case 4:
      return (reader.readStringOrNull(offset)) as P;
    case 5:
      return (_CategorydisplayModeValueEnumMap[reader.readStringOrNull(offset)])
          as P;
    case 6:
      return (reader.readLongOrNull(offset)) as P;
    case 7:
      return (reader.readLongOrNull(offset)) as P;
    case 8:
      return (reader.readStringList(offset)) as P;
    case 9:
      return (reader.readLongList(offset)) as P;
    case 10:
      return (reader.readStringList(offset)) as P;
    case 11:
      return (reader.readBoolOrNull(offset)) as P;
    case 12:
      return (reader.readStringOrNull(offset)) as P;
    case 13:
      return (reader.readBoolOrNull(offset)) as P;
    case 14:
      return (reader.readBool(offset)) as P;
    case 15:
      return (reader.readBoolOrNull(offset)) as P;
    case 16:
      return (reader.readBool(offset)) as P;
    case 17:
      return (reader.readBoolOrNull(offset)) as P;
    case 18:
      return (reader.readBoolOrNull(offset)) as P;
    case 19:
      return (reader.readBool(offset)) as P;
    case 20:
      return (reader.readString(offset)) as P;
    case 21:
      return (reader.readString(offset)) as P;
    case 22:
      return (reader.readString(offset)) as P;
    case 23:
      return (reader.readLongOrNull(offset)) as P;
    case 24:
      return (reader.readLongOrNull(offset)) as P;
    case 25:
      return (reader.readLong(offset)) as P;
    case 26:
      return (reader.readBoolOrNull(offset)) as P;
    case 27:
      return (reader.readBoolOrNull(offset)) as P;
    case 28:
      return (reader.readBoolOrNull(offset)) as P;
    case 29:
      return (reader.readStringOrNull(offset)) as P;
    case 30:
      return (reader.readBoolOrNull(offset)) as P;
    case 31:
      return (reader.readBoolOrNull(offset)) as P;
    case 32:
      return (_CategorytypeValueEnumMap[reader.readStringOrNull(offset)]) as P;
    case 33:
      return (_CategorytypeIndexValueEnumMap[reader.readStringOrNull(offset)])
          as P;
    case 34:
      return (reader.readLongOrNull(offset)) as P;
    case 35:
      return (reader.readLongOrNull(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

const _CategorydisplayModeEnumValueMap = {
  r'pill': r'pill',
  r'underline': r'underline',
  r'filled': r'filled',
};
const _CategorydisplayModeValueEnumMap = {
  r'pill': CategoryDisplayMode.pill,
  r'underline': CategoryDisplayMode.underline,
  r'filled': CategoryDisplayMode.filled,
};
const _CategorytypeEnumValueMap = {
  r'manga': r'manga',
  r'anime': r'anime',
  r'mixed': r'mixed',
  r'smart': r'smart',
  r'system': r'system',
};
const _CategorytypeValueEnumMap = {
  r'manga': CategoryType.manga,
  r'anime': CategoryType.anime,
  r'mixed': CategoryType.mixed,
  r'smart': CategoryType.smart,
  r'system': CategoryType.system,
};
const _CategorytypeIndexEnumValueMap = {
  r'manga': r'manga',
  r'anime': r'anime',
  r'mixed': r'mixed',
  r'smart': r'smart',
  r'system': r'system',
};
const _CategorytypeIndexValueEnumMap = {
  r'manga': CategoryType.manga,
  r'anime': CategoryType.anime,
  r'mixed': CategoryType.mixed,
  r'smart': CategoryType.smart,
  r'system': CategoryType.system,
};

Id _categoryGetId(Category object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _categoryGetLinks(Category object) {
  return [object.source];
}

void _categoryAttach(IsarCollection<dynamic> col, Id id, Category object) {
  object.id = id;
  object.source.attach(col, col.isar.collection<Source>(), r'source', id);
}

extension CategoryByIndex on IsarCollection<Category> {
  Future<Category?> getByNameTypeIndexType(
      String nameTypeIndex, CategoryType? type) {
    return getByIndex(r'nameTypeIndex_type', [nameTypeIndex, type]);
  }

  Category? getByNameTypeIndexTypeSync(
      String nameTypeIndex, CategoryType? type) {
    return getByIndexSync(r'nameTypeIndex_type', [nameTypeIndex, type]);
  }

  Future<bool> deleteByNameTypeIndexType(
      String nameTypeIndex, CategoryType? type) {
    return deleteByIndex(r'nameTypeIndex_type', [nameTypeIndex, type]);
  }

  bool deleteByNameTypeIndexTypeSync(String nameTypeIndex, CategoryType? type) {
    return deleteByIndexSync(r'nameTypeIndex_type', [nameTypeIndex, type]);
  }

  Future<List<Category?>> getAllByNameTypeIndexType(
      List<String> nameTypeIndexValues, List<CategoryType?> typeValues) {
    final len = nameTypeIndexValues.length;
    assert(
        typeValues.length == len, 'All index values must have the same length');
    final values = <List<dynamic>>[];
    for (var i = 0; i < len; i++) {
      values.add([nameTypeIndexValues[i], typeValues[i]]);
    }

    return getAllByIndex(r'nameTypeIndex_type', values);
  }

  List<Category?> getAllByNameTypeIndexTypeSync(
      List<String> nameTypeIndexValues, List<CategoryType?> typeValues) {
    final len = nameTypeIndexValues.length;
    assert(
        typeValues.length == len, 'All index values must have the same length');
    final values = <List<dynamic>>[];
    for (var i = 0; i < len; i++) {
      values.add([nameTypeIndexValues[i], typeValues[i]]);
    }

    return getAllByIndexSync(r'nameTypeIndex_type', values);
  }

  Future<int> deleteAllByNameTypeIndexType(
      List<String> nameTypeIndexValues, List<CategoryType?> typeValues) {
    final len = nameTypeIndexValues.length;
    assert(
        typeValues.length == len, 'All index values must have the same length');
    final values = <List<dynamic>>[];
    for (var i = 0; i < len; i++) {
      values.add([nameTypeIndexValues[i], typeValues[i]]);
    }

    return deleteAllByIndex(r'nameTypeIndex_type', values);
  }

  int deleteAllByNameTypeIndexTypeSync(
      List<String> nameTypeIndexValues, List<CategoryType?> typeValues) {
    final len = nameTypeIndexValues.length;
    assert(
        typeValues.length == len, 'All index values must have the same length');
    final values = <List<dynamic>>[];
    for (var i = 0; i < len; i++) {
      values.add([nameTypeIndexValues[i], typeValues[i]]);
    }

    return deleteAllByIndexSync(r'nameTypeIndex_type', values);
  }

  Future<Id> putByNameTypeIndexType(Category object) {
    return putByIndex(r'nameTypeIndex_type', object);
  }

  Id putByNameTypeIndexTypeSync(Category object, {bool saveLinks = true}) {
    return putByIndexSync(r'nameTypeIndex_type', object, saveLinks: saveLinks);
  }

  Future<List<Id>> putAllByNameTypeIndexType(List<Category> objects) {
    return putAllByIndex(r'nameTypeIndex_type', objects);
  }

  List<Id> putAllByNameTypeIndexTypeSync(List<Category> objects,
      {bool saveLinks = true}) {
    return putAllByIndexSync(r'nameTypeIndex_type', objects,
        saveLinks: saveLinks);
  }
}

extension CategoryQueryWhereSort on QueryBuilder<Category, Category, QWhere> {
  QueryBuilder<Category, Category, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }

  QueryBuilder<Category, Category, QAfterWhere> anyPositionIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'positionIndex'),
      );
    });
  }

  QueryBuilder<Category, Category, QAfterWhere> anyIsDefaultIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'isDefaultIndex'),
      );
    });
  }

  QueryBuilder<Category, Category, QAfterWhere> anyIsHiddenIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'isHiddenIndex'),
      );
    });
  }

  QueryBuilder<Category, Category, QAfterWhere> anyIsSmartIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'isSmartIndex'),
      );
    });
  }
}

extension CategoryQueryWhere on QueryBuilder<Category, Category, QWhereClause> {
  QueryBuilder<Category, Category, QAfterWhereClause> idEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> idNotEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> idGreaterThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> idLessThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> nameIndexEqualTo(
      String nameIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'nameIndex',
        value: [nameIndex],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> nameIndexNotEqualTo(
      String nameIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameIndex',
              lower: [],
              upper: [nameIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameIndex',
              lower: [nameIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameIndex',
              lower: [nameIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameIndex',
              lower: [],
              upper: [nameIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause>
      nameTypeIndexEqualToAnyType(String nameTypeIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'nameTypeIndex_type',
        value: [nameTypeIndex],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause>
      nameTypeIndexNotEqualToAnyType(String nameTypeIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameTypeIndex_type',
              lower: [],
              upper: [nameTypeIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameTypeIndex_type',
              lower: [nameTypeIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameTypeIndex_type',
              lower: [nameTypeIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameTypeIndex_type',
              lower: [],
              upper: [nameTypeIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause>
      nameTypeIndexEqualToTypeIsNull(String nameTypeIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'nameTypeIndex_type',
        value: [nameTypeIndex, null],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause>
      nameTypeIndexEqualToTypeIsNotNull(String nameTypeIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'nameTypeIndex_type',
        lower: [nameTypeIndex, null],
        includeLower: false,
        upper: [
          nameTypeIndex,
        ],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> nameTypeIndexTypeEqualTo(
      String nameTypeIndex, CategoryType? type) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'nameTypeIndex_type',
        value: [nameTypeIndex, type],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause>
      nameTypeIndexEqualToTypeNotEqualTo(
          String nameTypeIndex, CategoryType? type) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameTypeIndex_type',
              lower: [nameTypeIndex],
              upper: [nameTypeIndex, type],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameTypeIndex_type',
              lower: [nameTypeIndex, type],
              includeLower: false,
              upper: [nameTypeIndex],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameTypeIndex_type',
              lower: [nameTypeIndex, type],
              includeLower: false,
              upper: [nameTypeIndex],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'nameTypeIndex_type',
              lower: [nameTypeIndex],
              upper: [nameTypeIndex, type],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> positionIndexEqualTo(
      int positionIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'positionIndex',
        value: [positionIndex],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> positionIndexNotEqualTo(
      int positionIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'positionIndex',
              lower: [],
              upper: [positionIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'positionIndex',
              lower: [positionIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'positionIndex',
              lower: [positionIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'positionIndex',
              lower: [],
              upper: [positionIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> positionIndexGreaterThan(
    int positionIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'positionIndex',
        lower: [positionIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> positionIndexLessThan(
    int positionIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'positionIndex',
        lower: [],
        upper: [positionIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> positionIndexBetween(
    int lowerPositionIndex,
    int upperPositionIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'positionIndex',
        lower: [lowerPositionIndex],
        includeLower: includeLower,
        upper: [upperPositionIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> typeIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'typeIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> typeIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'typeIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> typeIndexEqualTo(
      CategoryType? typeIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'typeIndex',
        value: [typeIndex],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> typeIndexNotEqualTo(
      CategoryType? typeIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'typeIndex',
              lower: [],
              upper: [typeIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'typeIndex',
              lower: [typeIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'typeIndex',
              lower: [typeIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'typeIndex',
              lower: [],
              upper: [typeIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> isDefaultIndexEqualTo(
      bool isDefaultIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'isDefaultIndex',
        value: [isDefaultIndex],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> isDefaultIndexNotEqualTo(
      bool isDefaultIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDefaultIndex',
              lower: [],
              upper: [isDefaultIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDefaultIndex',
              lower: [isDefaultIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDefaultIndex',
              lower: [isDefaultIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDefaultIndex',
              lower: [],
              upper: [isDefaultIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> isHiddenIndexEqualTo(
      bool isHiddenIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'isHiddenIndex',
        value: [isHiddenIndex],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> isHiddenIndexNotEqualTo(
      bool isHiddenIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isHiddenIndex',
              lower: [],
              upper: [isHiddenIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isHiddenIndex',
              lower: [isHiddenIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isHiddenIndex',
              lower: [isHiddenIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isHiddenIndex',
              lower: [],
              upper: [isHiddenIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> isSmartIndexEqualTo(
      bool isSmartIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'isSmartIndex',
        value: [isSmartIndex],
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterWhereClause> isSmartIndexNotEqualTo(
      bool isSmartIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSmartIndex',
              lower: [],
              upper: [isSmartIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSmartIndex',
              lower: [isSmartIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSmartIndex',
              lower: [isSmartIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSmartIndex',
              lower: [],
              upper: [isSmartIndex],
              includeUpper: false,
            ));
      }
    });
  }
}

extension CategoryQueryFilter
    on QueryBuilder<Category, Category, QFilterCondition> {
  QueryBuilder<Category, Category, QAfterFilterCondition> autoDownloadIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'autoDownload',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      autoDownloadIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'autoDownload',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> autoDownloadEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'autoDownload',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      autoDownloadCountIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'autoDownloadCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      autoDownloadCountIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'autoDownloadCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      autoDownloadCountEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'autoDownloadCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      autoDownloadCountGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'autoDownloadCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      autoDownloadCountLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'autoDownloadCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      autoDownloadCountBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'autoDownloadCount',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'color',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'color',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'color',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'color',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'color',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'color',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'color',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'color',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'color',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'color',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'color',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> colorIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'color',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> createdAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'createdAt',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> createdAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'createdAt',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> createdAtEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'createdAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> createdAtGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'createdAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> createdAtLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'createdAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> createdAtBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'createdAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> descriptionIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'description',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      descriptionIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'description',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> descriptionEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'description',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      descriptionGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'description',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> descriptionLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'description',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> descriptionBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'description',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> descriptionStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'description',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> descriptionEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'description',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> descriptionContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'description',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> descriptionMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'description',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> descriptionIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'description',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      descriptionIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'description',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> displayModeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'displayMode',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      displayModeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'displayMode',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> displayModeEqualTo(
    CategoryDisplayMode? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'displayMode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      displayModeGreaterThan(
    CategoryDisplayMode? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'displayMode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> displayModeLessThan(
    CategoryDisplayMode? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'displayMode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> displayModeBetween(
    CategoryDisplayMode? lower,
    CategoryDisplayMode? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'displayMode',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> displayModeStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'displayMode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> displayModeEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'displayMode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> displayModeContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'displayMode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> displayModeMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'displayMode',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> displayModeIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'displayMode',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      displayModeIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'displayMode',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      downloadedCountIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'downloadedCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      downloadedCountIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'downloadedCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      downloadedCountEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'downloadedCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      downloadedCountGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'downloadedCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      downloadedCountLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'downloadedCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      downloadedCountBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'downloadedCount',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> entryCountIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'entryCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      entryCountIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'entryCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> entryCountEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'entryCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> entryCountGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'entryCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> entryCountLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'entryCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> entryCountBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'entryCount',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'filterSourceIds',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'filterSourceIds',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsElementEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'filterSourceIds',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'filterSourceIds',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'filterSourceIds',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'filterSourceIds',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsElementStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'filterSourceIds',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsElementEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'filterSourceIds',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsElementContains(String value,
          {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'filterSourceIds',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsElementMatches(String pattern,
          {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'filterSourceIds',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'filterSourceIds',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'filterSourceIds',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsLengthEqualTo(int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterSourceIds',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterSourceIds',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterSourceIds',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterSourceIds',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterSourceIds',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterSourceIdsLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterSourceIds',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'filterStatuses',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'filterStatuses',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesElementEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'filterStatuses',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesElementGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'filterStatuses',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesElementLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'filterStatuses',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesElementBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'filterStatuses',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesLengthEqualTo(int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterStatuses',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterStatuses',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterStatuses',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterStatuses',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterStatuses',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterStatusesLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterStatuses',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> filterTagsIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'filterTags',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'filterTags',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsElementEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'filterTags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'filterTags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'filterTags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'filterTags',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsElementStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'filterTags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsElementEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'filterTags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsElementContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'filterTags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsElementMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'filterTags',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'filterTags',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'filterTags',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsLengthEqualTo(int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterTags',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> filterTagsIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterTags',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterTags',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterTags',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterTags',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      filterTagsLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'filterTags',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      hideReadEntriesIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'hideReadEntries',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      hideReadEntriesIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'hideReadEntries',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      hideReadEntriesEqualTo(bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'hideReadEntries',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'icon',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'icon',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'icon',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'icon',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'icon',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'icon',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'icon',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'icon',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'icon',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'icon',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'icon',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> iconIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'icon',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> idEqualTo(Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isDefaultIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isDefault',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isDefaultIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isDefault',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isDefaultEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isDefault',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isDefaultIndexEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isDefaultIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isHiddenIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isHidden',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isHiddenIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isHidden',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isHiddenEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isHidden',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isHiddenIndexEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isHiddenIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isLockedIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isLocked',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isLockedIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isLocked',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isLockedEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isLocked',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isSmartIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isSmart',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isSmartIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isSmart',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isSmartEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isSmart',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> isSmartIndexEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isSmartIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'name',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'name',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'name',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'name',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIndexEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'nameIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIndexGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'nameIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIndexLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'nameIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIndexBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'nameIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'nameIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'nameIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIndexContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'nameIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'nameIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'nameIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      nameIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'nameIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameTypeIndexEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'nameTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      nameTypeIndexGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'nameTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameTypeIndexLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'nameTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameTypeIndexBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'nameTypeIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      nameTypeIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'nameTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameTypeIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'nameTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameTypeIndexContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'nameTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> nameTypeIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'nameTypeIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      nameTypeIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'nameTypeIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      nameTypeIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'nameTypeIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> newCountIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'newCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> newCountIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'newCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> newCountEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'newCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> newCountGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'newCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> newCountLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'newCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> newCountBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'newCount',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> positionIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'position',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> positionIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'position',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> positionEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'position',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> positionGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'position',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> positionLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'position',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> positionBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'position',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> positionIndexEqualTo(
      int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'positionIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      positionIndexGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'positionIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> positionIndexLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'positionIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> positionIndexBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'positionIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> showCountIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'showCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> showCountIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'showCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> showCountEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'showCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      showDownloadBadgeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'showDownloadBadge',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      showDownloadBadgeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'showDownloadBadge',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      showDownloadBadgeEqualTo(bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'showDownloadBadge',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> showNewBadgeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'showNewBadge',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      showNewBadgeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'showNewBadge',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> showNewBadgeEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'showNewBadge',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> smartQueryIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'smartQuery',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      smartQueryIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'smartQuery',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> smartQueryEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'smartQuery',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> smartQueryGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'smartQuery',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> smartQueryLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'smartQuery',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> smartQueryBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'smartQuery',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> smartQueryStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'smartQuery',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> smartQueryEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'smartQuery',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> smartQueryContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'smartQuery',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> smartQueryMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'smartQuery',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> smartQueryIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'smartQuery',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      smartQueryIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'smartQuery',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      sortAscendingIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'sortAscending',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      sortAscendingIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'sortAscending',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> sortAscendingEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sortAscending',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      sortByLastReadIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'sortByLastRead',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      sortByLastReadIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'sortByLastRead',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> sortByLastReadEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sortByLastRead',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'type',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'type',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeEqualTo(
    CategoryType? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeGreaterThan(
    CategoryType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeLessThan(
    CategoryType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeBetween(
    CategoryType? lower,
    CategoryType? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'type',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'type',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'type',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'type',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'typeIndex',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'typeIndex',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexEqualTo(
    CategoryType? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'typeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexGreaterThan(
    CategoryType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'typeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexLessThan(
    CategoryType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'typeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexBetween(
    CategoryType? lower,
    CategoryType? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'typeIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'typeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'typeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'typeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'typeIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> typeIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'typeIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      typeIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'typeIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> unreadCountIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'unreadCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      unreadCountIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'unreadCount',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> unreadCountEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'unreadCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      unreadCountGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'unreadCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> unreadCountLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'unreadCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> unreadCountBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'unreadCount',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> updatedAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'updatedAt',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> updatedAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'updatedAt',
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> updatedAtEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> updatedAtGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> updatedAtLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> updatedAtBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'updatedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }
}

extension CategoryQueryObject
    on QueryBuilder<Category, Category, QFilterCondition> {}

extension CategoryQueryLinks
    on QueryBuilder<Category, Category, QFilterCondition> {
  QueryBuilder<Category, Category, QAfterFilterCondition> source(
      FilterQuery<Source> q) {
    return QueryBuilder.apply(this, (query) {
      return query.link(q, r'source');
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> sourceLengthEqualTo(
      int length) {
    return QueryBuilder.apply(this, (query) {
      return query.linkLength(r'source', length, true, length, true);
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> sourceIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.linkLength(r'source', 0, true, 0, true);
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> sourceIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.linkLength(r'source', 0, false, 999999, true);
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> sourceLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.linkLength(r'source', 0, true, length, include);
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition>
      sourceLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.linkLength(r'source', length, include, 999999, true);
    });
  }

  QueryBuilder<Category, Category, QAfterFilterCondition> sourceLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.linkLength(
          r'source', lower, includeLower, upper, includeUpper);
    });
  }
}

extension CategoryQuerySortBy on QueryBuilder<Category, Category, QSortBy> {
  QueryBuilder<Category, Category, QAfterSortBy> sortByAutoDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'autoDownload', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByAutoDownloadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'autoDownload', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByAutoDownloadCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'autoDownloadCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByAutoDownloadCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'autoDownloadCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByColor() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'color', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByColorDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'color', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByCreatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByCreatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByDescription() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'description', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByDescriptionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'description', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByDisplayMode() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'displayMode', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByDisplayModeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'displayMode', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByDownloadedCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadedCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByDownloadedCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadedCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByEntryCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'entryCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByEntryCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'entryCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByHideReadEntries() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hideReadEntries', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByHideReadEntriesDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hideReadEntries', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIcon() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'icon', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIconDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'icon', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsDefault() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDefault', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsDefaultDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDefault', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsDefaultIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDefaultIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsDefaultIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDefaultIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsHidden() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isHidden', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsHiddenDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isHidden', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsHiddenIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isHiddenIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsHiddenIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isHiddenIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsLocked() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isLocked', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsLockedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isLocked', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsSmart() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSmart', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsSmartDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSmart', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsSmartIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSmartIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByIsSmartIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSmartIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByName() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'name', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByNameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'name', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByNameIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nameIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByNameIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nameIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByNameTypeIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nameTypeIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByNameTypeIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nameTypeIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByNewCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'newCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByNewCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'newCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByPosition() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'position', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByPositionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'position', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByPositionIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByPositionIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByShowCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByShowCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByShowDownloadBadge() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showDownloadBadge', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByShowDownloadBadgeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showDownloadBadge', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByShowNewBadge() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showNewBadge', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByShowNewBadgeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showNewBadge', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortBySmartQuery() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'smartQuery', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortBySmartQueryDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'smartQuery', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortBySortAscending() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sortAscending', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortBySortAscendingDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sortAscending', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortBySortByLastRead() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sortByLastRead', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortBySortByLastReadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sortByLastRead', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByTypeIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'typeIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByTypeIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'typeIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByUnreadCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'unreadCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByUnreadCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'unreadCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> sortByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }
}

extension CategoryQuerySortThenBy
    on QueryBuilder<Category, Category, QSortThenBy> {
  QueryBuilder<Category, Category, QAfterSortBy> thenByAutoDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'autoDownload', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByAutoDownloadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'autoDownload', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByAutoDownloadCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'autoDownloadCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByAutoDownloadCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'autoDownloadCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByColor() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'color', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByColorDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'color', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByCreatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByCreatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByDescription() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'description', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByDescriptionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'description', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByDisplayMode() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'displayMode', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByDisplayModeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'displayMode', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByDownloadedCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadedCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByDownloadedCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadedCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByEntryCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'entryCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByEntryCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'entryCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByHideReadEntries() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hideReadEntries', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByHideReadEntriesDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hideReadEntries', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIcon() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'icon', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIconDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'icon', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsDefault() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDefault', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsDefaultDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDefault', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsDefaultIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDefaultIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsDefaultIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDefaultIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsHidden() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isHidden', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsHiddenDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isHidden', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsHiddenIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isHiddenIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsHiddenIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isHiddenIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsLocked() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isLocked', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsLockedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isLocked', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsSmart() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSmart', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsSmartDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSmart', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsSmartIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSmartIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByIsSmartIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSmartIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByName() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'name', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByNameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'name', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByNameIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nameIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByNameIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nameIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByNameTypeIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nameTypeIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByNameTypeIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nameTypeIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByNewCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'newCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByNewCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'newCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByPosition() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'position', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByPositionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'position', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByPositionIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByPositionIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByShowCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByShowCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByShowDownloadBadge() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showDownloadBadge', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByShowDownloadBadgeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showDownloadBadge', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByShowNewBadge() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showNewBadge', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByShowNewBadgeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'showNewBadge', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenBySmartQuery() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'smartQuery', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenBySmartQueryDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'smartQuery', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenBySortAscending() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sortAscending', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenBySortAscendingDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sortAscending', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenBySortByLastRead() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sortByLastRead', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenBySortByLastReadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sortByLastRead', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByTypeIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'typeIndex', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByTypeIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'typeIndex', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByUnreadCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'unreadCount', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByUnreadCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'unreadCount', Sort.desc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<Category, Category, QAfterSortBy> thenByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }
}

extension CategoryQueryWhereDistinct
    on QueryBuilder<Category, Category, QDistinct> {
  QueryBuilder<Category, Category, QDistinct> distinctByAutoDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'autoDownload');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByAutoDownloadCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'autoDownloadCount');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByColor(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'color', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByCreatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'createdAt');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByDescription(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'description', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByDisplayMode(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'displayMode', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByDownloadedCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'downloadedCount');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByEntryCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'entryCount');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByFilterSourceIds() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'filterSourceIds');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByFilterStatuses() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'filterStatuses');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByFilterTags() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'filterTags');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByHideReadEntries() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'hideReadEntries');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByIcon(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'icon', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByIsDefault() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isDefault');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByIsDefaultIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isDefaultIndex');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByIsHidden() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isHidden');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByIsHiddenIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isHiddenIndex');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByIsLocked() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isLocked');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByIsSmart() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isSmart');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByIsSmartIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isSmartIndex');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByName(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'name', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByNameIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'nameIndex', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByNameTypeIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'nameTypeIndex',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByNewCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'newCount');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByPosition() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'position');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByPositionIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'positionIndex');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByShowCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'showCount');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByShowDownloadBadge() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'showDownloadBadge');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByShowNewBadge() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'showNewBadge');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctBySmartQuery(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'smartQuery', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctBySortAscending() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'sortAscending');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctBySortByLastRead() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'sortByLastRead');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByType(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'type', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByTypeIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'typeIndex', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByUnreadCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'unreadCount');
    });
  }

  QueryBuilder<Category, Category, QDistinct> distinctByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'updatedAt');
    });
  }
}

extension CategoryQueryProperty
    on QueryBuilder<Category, Category, QQueryProperty> {
  QueryBuilder<Category, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> autoDownloadProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'autoDownload');
    });
  }

  QueryBuilder<Category, int?, QQueryOperations> autoDownloadCountProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'autoDownloadCount');
    });
  }

  QueryBuilder<Category, String?, QQueryOperations> colorProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'color');
    });
  }

  QueryBuilder<Category, int?, QQueryOperations> createdAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'createdAt');
    });
  }

  QueryBuilder<Category, String?, QQueryOperations> descriptionProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'description');
    });
  }

  QueryBuilder<Category, CategoryDisplayMode?, QQueryOperations>
      displayModeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'displayMode');
    });
  }

  QueryBuilder<Category, int?, QQueryOperations> downloadedCountProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'downloadedCount');
    });
  }

  QueryBuilder<Category, int?, QQueryOperations> entryCountProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'entryCount');
    });
  }

  QueryBuilder<Category, List<String>?, QQueryOperations>
      filterSourceIdsProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'filterSourceIds');
    });
  }

  QueryBuilder<Category, List<int>?, QQueryOperations>
      filterStatusesProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'filterStatuses');
    });
  }

  QueryBuilder<Category, List<String>?, QQueryOperations> filterTagsProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'filterTags');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> hideReadEntriesProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'hideReadEntries');
    });
  }

  QueryBuilder<Category, String?, QQueryOperations> iconProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'icon');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> isDefaultProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isDefault');
    });
  }

  QueryBuilder<Category, bool, QQueryOperations> isDefaultIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isDefaultIndex');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> isHiddenProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isHidden');
    });
  }

  QueryBuilder<Category, bool, QQueryOperations> isHiddenIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isHiddenIndex');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> isLockedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isLocked');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> isSmartProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isSmart');
    });
  }

  QueryBuilder<Category, bool, QQueryOperations> isSmartIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isSmartIndex');
    });
  }

  QueryBuilder<Category, String, QQueryOperations> nameProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'name');
    });
  }

  QueryBuilder<Category, String, QQueryOperations> nameIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'nameIndex');
    });
  }

  QueryBuilder<Category, String, QQueryOperations> nameTypeIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'nameTypeIndex');
    });
  }

  QueryBuilder<Category, int?, QQueryOperations> newCountProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'newCount');
    });
  }

  QueryBuilder<Category, int?, QQueryOperations> positionProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'position');
    });
  }

  QueryBuilder<Category, int, QQueryOperations> positionIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'positionIndex');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> showCountProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'showCount');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> showDownloadBadgeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'showDownloadBadge');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> showNewBadgeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'showNewBadge');
    });
  }

  QueryBuilder<Category, String?, QQueryOperations> smartQueryProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'smartQuery');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> sortAscendingProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'sortAscending');
    });
  }

  QueryBuilder<Category, bool?, QQueryOperations> sortByLastReadProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'sortByLastRead');
    });
  }

  QueryBuilder<Category, CategoryType?, QQueryOperations> typeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'type');
    });
  }

  QueryBuilder<Category, CategoryType?, QQueryOperations> typeIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'typeIndex');
    });
  }

  QueryBuilder<Category, int?, QQueryOperations> unreadCountProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'unreadCount');
    });
  }

  QueryBuilder<Category, int?, QQueryOperations> updatedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'updatedAt');
    });
  }
}
