// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'download.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetDownloadCollection on Isar {
  IsarCollection<Download> get downloads => this.collection();
}

const DownloadSchema = CollectionSchema(
  name: r'Download',
  id: 5905484153212786579,
  properties: {
    r'audioCodec': PropertySchema(
      id: 0,
      name: r'audioCodec',
      type: IsarType.string,
    ),
    r'categoryId': PropertySchema(
      id: 1,
      name: r'categoryId',
      type: IsarType.long,
    ),
    r'chapterId': PropertySchema(
      id: 2,
      name: r'chapterId',
      type: IsarType.long,
    ),
    r'chapterIdIndex': PropertySchema(
      id: 3,
      name: r'chapterIdIndex',
      type: IsarType.long,
    ),
    r'chapterIdString': PropertySchema(
      id: 4,
      name: r'chapterIdString',
      type: IsarType.string,
    ),
    r'chapterName': PropertySchema(
      id: 5,
      name: r'chapterName',
      type: IsarType.string,
    ),
    r'chapterNumber': PropertySchema(
      id: 6,
      name: r'chapterNumber',
      type: IsarType.string,
    ),
    r'chargingOnly': PropertySchema(
      id: 7,
      name: r'chargingOnly',
      type: IsarType.bool,
    ),
    r'completedAt': PropertySchema(
      id: 8,
      name: r'completedAt',
      type: IsarType.long,
    ),
    r'containerFormat': PropertySchema(
      id: 9,
      name: r'containerFormat',
      type: IsarType.string,
    ),
    r'deleteAfterRead': PropertySchema(
      id: 10,
      name: r'deleteAfterRead',
      type: IsarType.bool,
    ),
    r'deviceId': PropertySchema(
      id: 11,
      name: r'deviceId',
      type: IsarType.string,
    ),
    r'downloadDir': PropertySchema(
      id: 12,
      name: r'downloadDir',
      type: IsarType.string,
    ),
    r'downloadPath': PropertySchema(
      id: 13,
      name: r'downloadPath',
      type: IsarType.string,
    ),
    r'downloadedBytes': PropertySchema(
      id: 14,
      name: r'downloadedBytes',
      type: IsarType.long,
    ),
    r'encrypt': PropertySchema(
      id: 15,
      name: r'encrypt',
      type: IsarType.bool,
    ),
    r'encryptionKey': PropertySchema(
      id: 16,
      name: r'encryptionKey',
      type: IsarType.string,
    ),
    r'failed': PropertySchema(
      id: 17,
      name: r'failed',
      type: IsarType.long,
    ),
    r'fileExtension': PropertySchema(
      id: 18,
      name: r'fileExtension',
      type: IsarType.string,
    ),
    r'fileSize': PropertySchema(
      id: 19,
      name: r'fileSize',
      type: IsarType.long,
    ),
    r'hashCode': PropertySchema(
      id: 20,
      name: r'hashCode',
      type: IsarType.long,
    ),
    r'headersJson': PropertySchema(
      id: 21,
      name: r'headersJson',
      type: IsarType.stringList,
    ),
    r'isAnime': PropertySchema(
      id: 22,
      name: r'isAnime',
      type: IsarType.bool,
    ),
    r'isBook': PropertySchema(
      id: 23,
      name: r'isBook',
      type: IsarType.bool,
    ),
    r'isDownloaded': PropertySchema(
      id: 24,
      name: r'isDownloaded',
      type: IsarType.bool,
    ),
    r'isDownloadedIndex': PropertySchema(
      id: 25,
      name: r'isDownloadedIndex',
      type: IsarType.bool,
    ),
    r'isManga': PropertySchema(
      id: 26,
      name: r'isManga',
      type: IsarType.bool,
    ),
    r'isPauseDownload': PropertySchema(
      id: 27,
      name: r'isPauseDownload',
      type: IsarType.bool,
    ),
    r'isStartDownload': PropertySchema(
      id: 28,
      name: r'isStartDownload',
      type: IsarType.bool,
    ),
    r'isStopDownload': PropertySchema(
      id: 29,
      name: r'isStopDownload',
      type: IsarType.bool,
    ),
    r'isSynced': PropertySchema(
      id: 30,
      name: r'isSynced',
      type: IsarType.bool,
    ),
    r'lastError': PropertySchema(
      id: 31,
      name: r'lastError',
      type: IsarType.string,
    ),
    r'lastStackTrace': PropertySchema(
      id: 32,
      name: r'lastStackTrace',
      type: IsarType.string,
    ),
    r'lastSyncedAt': PropertySchema(
      id: 33,
      name: r'lastSyncedAt',
      type: IsarType.long,
    ),
    r'mangaChapterIndex': PropertySchema(
      id: 34,
      name: r'mangaChapterIndex',
      type: IsarType.long,
    ),
    r'mangaCover': PropertySchema(
      id: 35,
      name: r'mangaCover',
      type: IsarType.string,
    ),
    r'mangaId': PropertySchema(
      id: 36,
      name: r'mangaId',
      type: IsarType.long,
    ),
    r'mangaIdIndex': PropertySchema(
      id: 37,
      name: r'mangaIdIndex',
      type: IsarType.long,
    ),
    r'mangaIdString': PropertySchema(
      id: 38,
      name: r'mangaIdString',
      type: IsarType.string,
    ),
    r'mangaTitle': PropertySchema(
      id: 39,
      name: r'mangaTitle',
      type: IsarType.string,
    ),
    r'maxRetries': PropertySchema(
      id: 40,
      name: r'maxRetries',
      type: IsarType.long,
    ),
    r'mediaType': PropertySchema(
      id: 41,
      name: r'mediaType',
      type: IsarType.string,
      enumMap: _DownloadmediaTypeEnumValueMap,
    ),
    r'mediaTypeIndex': PropertySchema(
      id: 42,
      name: r'mediaTypeIndex',
      type: IsarType.string,
      enumMap: _DownloadmediaTypeIndexEnumValueMap,
    ),
    r'mimeType': PropertySchema(
      id: 43,
      name: r'mimeType',
      type: IsarType.string,
    ),
    r'note': PropertySchema(
      id: 44,
      name: r'note',
      type: IsarType.string,
    ),
    r'password': PropertySchema(
      id: 45,
      name: r'password',
      type: IsarType.string,
    ),
    r'priority': PropertySchema(
      id: 46,
      name: r'priority',
      type: IsarType.string,
      enumMap: _DownloadpriorityEnumValueMap,
    ),
    r'priorityIndex': PropertySchema(
      id: 47,
      name: r'priorityIndex',
      type: IsarType.string,
      enumMap: _DownloadpriorityIndexEnumValueMap,
    ),
    r'queueScanIndex': PropertySchema(
      id: 48,
      name: r'queueScanIndex',
      type: IsarType.string,
      enumMap: _DownloadqueueScanIndexEnumValueMap,
    ),
    r'referer': PropertySchema(
      id: 49,
      name: r'referer',
      type: IsarType.string,
    ),
    r'requestedAt': PropertySchema(
      id: 50,
      name: r'requestedAt',
      type: IsarType.long,
    ),
    r'requestedAtIndex': PropertySchema(
      id: 51,
      name: r'requestedAtIndex',
      type: IsarType.long,
    ),
    r'retryCount': PropertySchema(
      id: 52,
      name: r'retryCount',
      type: IsarType.long,
    ),
    r'revision': PropertySchema(
      id: 53,
      name: r'revision',
      type: IsarType.long,
    ),
    r'savedFiles': PropertySchema(
      id: 54,
      name: r'savedFiles',
      type: IsarType.stringList,
    ),
    r'sourceId': PropertySchema(
      id: 55,
      name: r'sourceId',
      type: IsarType.string,
    ),
    r'sourceIdIndex': PropertySchema(
      id: 56,
      name: r'sourceIdIndex',
      type: IsarType.string,
    ),
    r'startedAt': PropertySchema(
      id: 57,
      name: r'startedAt',
      type: IsarType.long,
    ),
    r'state': PropertySchema(
      id: 58,
      name: r'state',
      type: IsarType.string,
      enumMap: _DownloadstateEnumValueMap,
    ),
    r'stateIndex': PropertySchema(
      id: 59,
      name: r'stateIndex',
      type: IsarType.string,
      enumMap: _DownloadstateIndexEnumValueMap,
    ),
    r'success': PropertySchema(
      id: 60,
      name: r'success',
      type: IsarType.long,
    ),
    r'tags': PropertySchema(
      id: 61,
      name: r'tags',
      type: IsarType.stringList,
    ),
    r'taskId': PropertySchema(
      id: 62,
      name: r'taskId',
      type: IsarType.string,
    ),
    r'taskIndex': PropertySchema(
      id: 63,
      name: r'taskIndex',
      type: IsarType.long,
    ),
    r'taskIndexIndex': PropertySchema(
      id: 64,
      name: r'taskIndexIndex',
      type: IsarType.long,
    ),
    r'total': PropertySchema(
      id: 65,
      name: r'total',
      type: IsarType.long,
    ),
    r'updatedAt': PropertySchema(
      id: 66,
      name: r'updatedAt',
      type: IsarType.long,
    ),
    r'url': PropertySchema(
      id: 67,
      name: r'url',
      type: IsarType.string,
    ),
    r'urls': PropertySchema(
      id: 68,
      name: r'urls',
      type: IsarType.stringList,
    ),
    r'username': PropertySchema(
      id: 69,
      name: r'username',
      type: IsarType.string,
    ),
    r'videoBitrate': PropertySchema(
      id: 70,
      name: r'videoBitrate',
      type: IsarType.long,
    ),
    r'videoCodec': PropertySchema(
      id: 71,
      name: r'videoCodec',
      type: IsarType.string,
    ),
    r'videoDuration': PropertySchema(
      id: 72,
      name: r'videoDuration',
      type: IsarType.long,
    ),
    r'videoQuality': PropertySchema(
      id: 73,
      name: r'videoQuality',
      type: IsarType.string,
    ),
    r'wifiOnly': PropertySchema(
      id: 74,
      name: r'wifiOnly',
      type: IsarType.bool,
    )
  },
  estimateSize: _downloadEstimateSize,
  serialize: _downloadSerialize,
  deserialize: _downloadDeserialize,
  deserializeProp: _downloadDeserializeProp,
  idName: r'id',
  indexes: {
    r'mangaIdIndex': IndexSchema(
      id: 5899444865427616617,
      name: r'mangaIdIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'mangaIdIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'chapterIdIndex': IndexSchema(
      id: 4785143513443022250,
      name: r'chapterIdIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'chapterIdIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'stateIndex': IndexSchema(
      id: -5841096252777046523,
      name: r'stateIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'stateIndex',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    ),
    r'priorityIndex': IndexSchema(
      id: 1513594599038388933,
      name: r'priorityIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'priorityIndex',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    ),
    r'taskIndexIndex': IndexSchema(
      id: -5662113405850878605,
      name: r'taskIndexIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'taskIndexIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'isDownloadedIndex': IndexSchema(
      id: -538162128458274253,
      name: r'isDownloadedIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'isDownloadedIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'sourceIdIndex': IndexSchema(
      id: -5064764038557396038,
      name: r'sourceIdIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'sourceIdIndex',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    ),
    r'mediaTypeIndex': IndexSchema(
      id: -6065007409749526479,
      name: r'mediaTypeIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'mediaTypeIndex',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    ),
    r'requestedAtIndex': IndexSchema(
      id: -3971380625767976049,
      name: r'requestedAtIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'requestedAtIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'queueScanIndex_priority_taskIndex': IndexSchema(
      id: -4411393530522754751,
      name: r'queueScanIndex_priority_taskIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'queueScanIndex',
          type: IndexType.hash,
          caseSensitive: true,
        ),
        IndexPropertySchema(
          name: r'priority',
          type: IndexType.hash,
          caseSensitive: true,
        ),
        IndexPropertySchema(
          name: r'taskIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'mangaChapterIndex_chapterId': IndexSchema(
      id: -9078075847608823625,
      name: r'mangaChapterIndex_chapterId',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'mangaChapterIndex',
          type: IndexType.value,
          caseSensitive: false,
        ),
        IndexPropertySchema(
          name: r'chapterId',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    )
  },
  links: {},
  embeddedSchemas: {},
  getId: _downloadGetId,
  getLinks: _downloadGetLinks,
  attach: _downloadAttach,
  version: '3.1.0+1',
);

int _downloadEstimateSize(
  Download object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  {
    final value = object.audioCodec;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.chapterIdString;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.chapterName;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.chapterNumber;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.containerFormat;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.deviceId;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.downloadDir;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.downloadPath;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.encryptionKey;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.fileExtension;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final list = object.headersJson;
    if (list != null) {
      bytesCount += 3 + list.length * 3;
      {
        for (var i = 0; i < list.length; i++) {
          final value = list[i];
          bytesCount += value.length * 3;
        }
      }
    }
  }
  {
    final value = object.lastError;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.lastStackTrace;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.mangaCover;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.mangaIdString;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.mangaTitle;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.mediaType;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.mediaTypeIndex;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.mimeType;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.note;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.password;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.priority;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.priorityIndex;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.queueScanIndex;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.referer;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final list = object.savedFiles;
    if (list != null) {
      bytesCount += 3 + list.length * 3;
      {
        for (var i = 0; i < list.length; i++) {
          final value = list[i];
          bytesCount += value.length * 3;
        }
      }
    }
  }
  {
    final value = object.sourceId;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.sourceIdIndex;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.state;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.stateIndex;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final list = object.tags;
    if (list != null) {
      bytesCount += 3 + list.length * 3;
      {
        for (var i = 0; i < list.length; i++) {
          final value = list[i];
          bytesCount += value.length * 3;
        }
      }
    }
  }
  {
    final value = object.taskId;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.url;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final list = object.urls;
    if (list != null) {
      bytesCount += 3 + list.length * 3;
      {
        for (var i = 0; i < list.length; i++) {
          final value = list[i];
          bytesCount += value.length * 3;
        }
      }
    }
  }
  {
    final value = object.username;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.videoCodec;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.videoQuality;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  return bytesCount;
}

void _downloadSerialize(
  Download object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeString(offsets[0], object.audioCodec);
  writer.writeLong(offsets[1], object.categoryId);
  writer.writeLong(offsets[2], object.chapterId);
  writer.writeLong(offsets[3], object.chapterIdIndex);
  writer.writeString(offsets[4], object.chapterIdString);
  writer.writeString(offsets[5], object.chapterName);
  writer.writeString(offsets[6], object.chapterNumber);
  writer.writeBool(offsets[7], object.chargingOnly);
  writer.writeLong(offsets[8], object.completedAt);
  writer.writeString(offsets[9], object.containerFormat);
  writer.writeBool(offsets[10], object.deleteAfterRead);
  writer.writeString(offsets[11], object.deviceId);
  writer.writeString(offsets[12], object.downloadDir);
  writer.writeString(offsets[13], object.downloadPath);
  writer.writeLong(offsets[14], object.downloadedBytes);
  writer.writeBool(offsets[15], object.encrypt);
  writer.writeString(offsets[16], object.encryptionKey);
  writer.writeLong(offsets[17], object.failed);
  writer.writeString(offsets[18], object.fileExtension);
  writer.writeLong(offsets[19], object.fileSize);
  writer.writeLong(offsets[20], object.hashCode);
  writer.writeStringList(offsets[21], object.headersJson);
  writer.writeBool(offsets[22], object.isAnime);
  writer.writeBool(offsets[23], object.isBook);
  writer.writeBool(offsets[24], object.isDownloaded);
  writer.writeBool(offsets[25], object.isDownloadedIndex);
  writer.writeBool(offsets[26], object.isManga);
  writer.writeBool(offsets[27], object.isPauseDownload);
  writer.writeBool(offsets[28], object.isStartDownload);
  writer.writeBool(offsets[29], object.isStopDownload);
  writer.writeBool(offsets[30], object.isSynced);
  writer.writeString(offsets[31], object.lastError);
  writer.writeString(offsets[32], object.lastStackTrace);
  writer.writeLong(offsets[33], object.lastSyncedAt);
  writer.writeLong(offsets[34], object.mangaChapterIndex);
  writer.writeString(offsets[35], object.mangaCover);
  writer.writeLong(offsets[36], object.mangaId);
  writer.writeLong(offsets[37], object.mangaIdIndex);
  writer.writeString(offsets[38], object.mangaIdString);
  writer.writeString(offsets[39], object.mangaTitle);
  writer.writeLong(offsets[40], object.maxRetries);
  writer.writeString(offsets[41], object.mediaType?.name);
  writer.writeString(offsets[42], object.mediaTypeIndex?.name);
  writer.writeString(offsets[43], object.mimeType);
  writer.writeString(offsets[44], object.note);
  writer.writeString(offsets[45], object.password);
  writer.writeString(offsets[46], object.priority?.name);
  writer.writeString(offsets[47], object.priorityIndex?.name);
  writer.writeString(offsets[48], object.queueScanIndex?.name);
  writer.writeString(offsets[49], object.referer);
  writer.writeLong(offsets[50], object.requestedAt);
  writer.writeLong(offsets[51], object.requestedAtIndex);
  writer.writeLong(offsets[52], object.retryCount);
  writer.writeLong(offsets[53], object.revision);
  writer.writeStringList(offsets[54], object.savedFiles);
  writer.writeString(offsets[55], object.sourceId);
  writer.writeString(offsets[56], object.sourceIdIndex);
  writer.writeLong(offsets[57], object.startedAt);
  writer.writeString(offsets[58], object.state?.name);
  writer.writeString(offsets[59], object.stateIndex?.name);
  writer.writeLong(offsets[60], object.success);
  writer.writeStringList(offsets[61], object.tags);
  writer.writeString(offsets[62], object.taskId);
  writer.writeLong(offsets[63], object.taskIndex);
  writer.writeLong(offsets[64], object.taskIndexIndex);
  writer.writeLong(offsets[65], object.total);
  writer.writeLong(offsets[66], object.updatedAt);
  writer.writeString(offsets[67], object.url);
  writer.writeStringList(offsets[68], object.urls);
  writer.writeString(offsets[69], object.username);
  writer.writeLong(offsets[70], object.videoBitrate);
  writer.writeString(offsets[71], object.videoCodec);
  writer.writeLong(offsets[72], object.videoDuration);
  writer.writeString(offsets[73], object.videoQuality);
  writer.writeBool(offsets[74], object.wifiOnly);
}

Download _downloadDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = Download(
    audioCodec: reader.readStringOrNull(offsets[0]),
    categoryId: reader.readLongOrNull(offsets[1]),
    chapterId: reader.readLongOrNull(offsets[2]),
    chapterIdString: reader.readStringOrNull(offsets[4]),
    chapterName: reader.readStringOrNull(offsets[5]),
    chapterNumber: reader.readStringOrNull(offsets[6]),
    chargingOnly: reader.readBoolOrNull(offsets[7]),
    completedAt: reader.readLongOrNull(offsets[8]),
    containerFormat: reader.readStringOrNull(offsets[9]),
    deleteAfterRead: reader.readBoolOrNull(offsets[10]),
    deviceId: reader.readStringOrNull(offsets[11]),
    downloadDir: reader.readStringOrNull(offsets[12]),
    downloadPath: reader.readStringOrNull(offsets[13]),
    downloadedBytes: reader.readLongOrNull(offsets[14]),
    encrypt: reader.readBoolOrNull(offsets[15]),
    encryptionKey: reader.readStringOrNull(offsets[16]),
    failed: reader.readLongOrNull(offsets[17]),
    fileExtension: reader.readStringOrNull(offsets[18]),
    fileSize: reader.readLongOrNull(offsets[19]),
    headersJson: reader.readStringList(offsets[21]),
    id: id,
    isAnime: reader.readBoolOrNull(offsets[22]),
    isBook: reader.readBoolOrNull(offsets[23]),
    isDownloaded: reader.readBoolOrNull(offsets[24]),
    isManga: reader.readBoolOrNull(offsets[26]),
    isPauseDownload: reader.readBoolOrNull(offsets[27]),
    isStartDownload: reader.readBoolOrNull(offsets[28]),
    isStopDownload: reader.readBoolOrNull(offsets[29]),
    isSynced: reader.readBoolOrNull(offsets[30]),
    lastError: reader.readStringOrNull(offsets[31]),
    lastStackTrace: reader.readStringOrNull(offsets[32]),
    lastSyncedAt: reader.readLongOrNull(offsets[33]),
    mangaCover: reader.readStringOrNull(offsets[35]),
    mangaId: reader.readLongOrNull(offsets[36]),
    mangaIdString: reader.readStringOrNull(offsets[38]),
    mangaTitle: reader.readStringOrNull(offsets[39]),
    maxRetries: reader.readLongOrNull(offsets[40]),
    mediaType:
        _DownloadmediaTypeValueEnumMap[reader.readStringOrNull(offsets[41])],
    mimeType: reader.readStringOrNull(offsets[43]),
    note: reader.readStringOrNull(offsets[44]),
    password: reader.readStringOrNull(offsets[45]),
    priority:
        _DownloadpriorityValueEnumMap[reader.readStringOrNull(offsets[46])],
    referer: reader.readStringOrNull(offsets[49]),
    requestedAt: reader.readLongOrNull(offsets[50]),
    retryCount: reader.readLongOrNull(offsets[52]),
    revision: reader.readLongOrNull(offsets[53]),
    savedFiles: reader.readStringList(offsets[54]),
    sourceId: reader.readStringOrNull(offsets[55]),
    startedAt: reader.readLongOrNull(offsets[57]),
    state: _DownloadstateValueEnumMap[reader.readStringOrNull(offsets[58])],
    success: reader.readLongOrNull(offsets[60]),
    tags: reader.readStringList(offsets[61]),
    taskId: reader.readStringOrNull(offsets[62]),
    taskIndex: reader.readLongOrNull(offsets[63]),
    total: reader.readLongOrNull(offsets[65]),
    updatedAt: reader.readLongOrNull(offsets[66]),
    url: reader.readStringOrNull(offsets[67]),
    urls: reader.readStringList(offsets[68]),
    username: reader.readStringOrNull(offsets[69]),
    videoBitrate: reader.readLongOrNull(offsets[70]),
    videoCodec: reader.readStringOrNull(offsets[71]),
    videoDuration: reader.readLongOrNull(offsets[72]),
    videoQuality: reader.readStringOrNull(offsets[73]),
    wifiOnly: reader.readBoolOrNull(offsets[74]),
  );
  return object;
}

P _downloadDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readStringOrNull(offset)) as P;
    case 1:
      return (reader.readLongOrNull(offset)) as P;
    case 2:
      return (reader.readLongOrNull(offset)) as P;
    case 3:
      return (reader.readLongOrNull(offset)) as P;
    case 4:
      return (reader.readStringOrNull(offset)) as P;
    case 5:
      return (reader.readStringOrNull(offset)) as P;
    case 6:
      return (reader.readStringOrNull(offset)) as P;
    case 7:
      return (reader.readBoolOrNull(offset)) as P;
    case 8:
      return (reader.readLongOrNull(offset)) as P;
    case 9:
      return (reader.readStringOrNull(offset)) as P;
    case 10:
      return (reader.readBoolOrNull(offset)) as P;
    case 11:
      return (reader.readStringOrNull(offset)) as P;
    case 12:
      return (reader.readStringOrNull(offset)) as P;
    case 13:
      return (reader.readStringOrNull(offset)) as P;
    case 14:
      return (reader.readLongOrNull(offset)) as P;
    case 15:
      return (reader.readBoolOrNull(offset)) as P;
    case 16:
      return (reader.readStringOrNull(offset)) as P;
    case 17:
      return (reader.readLongOrNull(offset)) as P;
    case 18:
      return (reader.readStringOrNull(offset)) as P;
    case 19:
      return (reader.readLongOrNull(offset)) as P;
    case 20:
      return (reader.readLong(offset)) as P;
    case 21:
      return (reader.readStringList(offset)) as P;
    case 22:
      return (reader.readBoolOrNull(offset)) as P;
    case 23:
      return (reader.readBoolOrNull(offset)) as P;
    case 24:
      return (reader.readBoolOrNull(offset)) as P;
    case 25:
      return (reader.readBool(offset)) as P;
    case 26:
      return (reader.readBoolOrNull(offset)) as P;
    case 27:
      return (reader.readBoolOrNull(offset)) as P;
    case 28:
      return (reader.readBoolOrNull(offset)) as P;
    case 29:
      return (reader.readBoolOrNull(offset)) as P;
    case 30:
      return (reader.readBoolOrNull(offset)) as P;
    case 31:
      return (reader.readStringOrNull(offset)) as P;
    case 32:
      return (reader.readStringOrNull(offset)) as P;
    case 33:
      return (reader.readLongOrNull(offset)) as P;
    case 34:
      return (reader.readLongOrNull(offset)) as P;
    case 35:
      return (reader.readStringOrNull(offset)) as P;
    case 36:
      return (reader.readLongOrNull(offset)) as P;
    case 37:
      return (reader.readLongOrNull(offset)) as P;
    case 38:
      return (reader.readStringOrNull(offset)) as P;
    case 39:
      return (reader.readStringOrNull(offset)) as P;
    case 40:
      return (reader.readLongOrNull(offset)) as P;
    case 41:
      return (_DownloadmediaTypeValueEnumMap[reader.readStringOrNull(offset)])
          as P;
    case 42:
      return (_DownloadmediaTypeIndexValueEnumMap[
          reader.readStringOrNull(offset)]) as P;
    case 43:
      return (reader.readStringOrNull(offset)) as P;
    case 44:
      return (reader.readStringOrNull(offset)) as P;
    case 45:
      return (reader.readStringOrNull(offset)) as P;
    case 46:
      return (_DownloadpriorityValueEnumMap[reader.readStringOrNull(offset)])
          as P;
    case 47:
      return (_DownloadpriorityIndexValueEnumMap[
          reader.readStringOrNull(offset)]) as P;
    case 48:
      return (_DownloadqueueScanIndexValueEnumMap[
          reader.readStringOrNull(offset)]) as P;
    case 49:
      return (reader.readStringOrNull(offset)) as P;
    case 50:
      return (reader.readLongOrNull(offset)) as P;
    case 51:
      return (reader.readLongOrNull(offset)) as P;
    case 52:
      return (reader.readLongOrNull(offset)) as P;
    case 53:
      return (reader.readLongOrNull(offset)) as P;
    case 54:
      return (reader.readStringList(offset)) as P;
    case 55:
      return (reader.readStringOrNull(offset)) as P;
    case 56:
      return (reader.readStringOrNull(offset)) as P;
    case 57:
      return (reader.readLongOrNull(offset)) as P;
    case 58:
      return (_DownloadstateValueEnumMap[reader.readStringOrNull(offset)]) as P;
    case 59:
      return (_DownloadstateIndexValueEnumMap[reader.readStringOrNull(offset)])
          as P;
    case 60:
      return (reader.readLongOrNull(offset)) as P;
    case 61:
      return (reader.readStringList(offset)) as P;
    case 62:
      return (reader.readStringOrNull(offset)) as P;
    case 63:
      return (reader.readLongOrNull(offset)) as P;
    case 64:
      return (reader.readLongOrNull(offset)) as P;
    case 65:
      return (reader.readLongOrNull(offset)) as P;
    case 66:
      return (reader.readLongOrNull(offset)) as P;
    case 67:
      return (reader.readStringOrNull(offset)) as P;
    case 68:
      return (reader.readStringList(offset)) as P;
    case 69:
      return (reader.readStringOrNull(offset)) as P;
    case 70:
      return (reader.readLongOrNull(offset)) as P;
    case 71:
      return (reader.readStringOrNull(offset)) as P;
    case 72:
      return (reader.readLongOrNull(offset)) as P;
    case 73:
      return (reader.readStringOrNull(offset)) as P;
    case 74:
      return (reader.readBoolOrNull(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

const _DownloadmediaTypeEnumValueMap = {
  r'manga': r'manga',
  r'anime': r'anime',
  r'epub': r'epub',
  r'pdf': r'pdf',
  r'audio': r'audio',
};
const _DownloadmediaTypeValueEnumMap = {
  r'manga': DownloadMediaType.manga,
  r'anime': DownloadMediaType.anime,
  r'epub': DownloadMediaType.epub,
  r'pdf': DownloadMediaType.pdf,
  r'audio': DownloadMediaType.audio,
};
const _DownloadmediaTypeIndexEnumValueMap = {
  r'manga': r'manga',
  r'anime': r'anime',
  r'epub': r'epub',
  r'pdf': r'pdf',
  r'audio': r'audio',
};
const _DownloadmediaTypeIndexValueEnumMap = {
  r'manga': DownloadMediaType.manga,
  r'anime': DownloadMediaType.anime,
  r'epub': DownloadMediaType.epub,
  r'pdf': DownloadMediaType.pdf,
  r'audio': DownloadMediaType.audio,
};
const _DownloadpriorityEnumValueMap = {
  r'low': r'low',
  r'normal': r'normal',
  r'high': r'high',
  r'urgent': r'urgent',
};
const _DownloadpriorityValueEnumMap = {
  r'low': DownloadPriority.low,
  r'normal': DownloadPriority.normal,
  r'high': DownloadPriority.high,
  r'urgent': DownloadPriority.urgent,
};
const _DownloadpriorityIndexEnumValueMap = {
  r'low': r'low',
  r'normal': r'normal',
  r'high': r'high',
  r'urgent': r'urgent',
};
const _DownloadpriorityIndexValueEnumMap = {
  r'low': DownloadPriority.low,
  r'normal': DownloadPriority.normal,
  r'high': DownloadPriority.high,
  r'urgent': DownloadPriority.urgent,
};
const _DownloadqueueScanIndexEnumValueMap = {
  r'queued': r'queued',
  r'downloading': r'downloading',
  r'paused': r'paused',
  r'stopped': r'stopped',
  r'completed': r'completed',
  r'failed': r'failed',
  r'cancelled': r'cancelled',
  r'preparing': r'preparing',
};
const _DownloadqueueScanIndexValueEnumMap = {
  r'queued': DownloadState.queued,
  r'downloading': DownloadState.downloading,
  r'paused': DownloadState.paused,
  r'stopped': DownloadState.stopped,
  r'completed': DownloadState.completed,
  r'failed': DownloadState.failed,
  r'cancelled': DownloadState.cancelled,
  r'preparing': DownloadState.preparing,
};
const _DownloadstateEnumValueMap = {
  r'queued': r'queued',
  r'downloading': r'downloading',
  r'paused': r'paused',
  r'stopped': r'stopped',
  r'completed': r'completed',
  r'failed': r'failed',
  r'cancelled': r'cancelled',
  r'preparing': r'preparing',
};
const _DownloadstateValueEnumMap = {
  r'queued': DownloadState.queued,
  r'downloading': DownloadState.downloading,
  r'paused': DownloadState.paused,
  r'stopped': DownloadState.stopped,
  r'completed': DownloadState.completed,
  r'failed': DownloadState.failed,
  r'cancelled': DownloadState.cancelled,
  r'preparing': DownloadState.preparing,
};
const _DownloadstateIndexEnumValueMap = {
  r'queued': r'queued',
  r'downloading': r'downloading',
  r'paused': r'paused',
  r'stopped': r'stopped',
  r'completed': r'completed',
  r'failed': r'failed',
  r'cancelled': r'cancelled',
  r'preparing': r'preparing',
};
const _DownloadstateIndexValueEnumMap = {
  r'queued': DownloadState.queued,
  r'downloading': DownloadState.downloading,
  r'paused': DownloadState.paused,
  r'stopped': DownloadState.stopped,
  r'completed': DownloadState.completed,
  r'failed': DownloadState.failed,
  r'cancelled': DownloadState.cancelled,
  r'preparing': DownloadState.preparing,
};

Id _downloadGetId(Download object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _downloadGetLinks(Download object) {
  return [];
}

void _downloadAttach(IsarCollection<dynamic> col, Id id, Download object) {
  object.id = id;
}

extension DownloadQueryWhereSort on QueryBuilder<Download, Download, QWhere> {
  QueryBuilder<Download, Download, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }

  QueryBuilder<Download, Download, QAfterWhere> anyMangaIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'mangaIdIndex'),
      );
    });
  }

  QueryBuilder<Download, Download, QAfterWhere> anyChapterIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'chapterIdIndex'),
      );
    });
  }

  QueryBuilder<Download, Download, QAfterWhere> anyTaskIndexIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'taskIndexIndex'),
      );
    });
  }

  QueryBuilder<Download, Download, QAfterWhere> anyIsDownloadedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'isDownloadedIndex'),
      );
    });
  }

  QueryBuilder<Download, Download, QAfterWhere> anyRequestedAtIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'requestedAtIndex'),
      );
    });
  }

  QueryBuilder<Download, Download, QAfterWhere>
      anyMangaChapterIndexChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'mangaChapterIndex_chapterId'),
      );
    });
  }
}

extension DownloadQueryWhere on QueryBuilder<Download, Download, QWhereClause> {
  QueryBuilder<Download, Download, QAfterWhereClause> idEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> idNotEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> idGreaterThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> idLessThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> mangaIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaIdIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> mangaIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaIdIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> mangaIdIndexEqualTo(
      int? mangaIdIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaIdIndex',
        value: [mangaIdIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> mangaIdIndexNotEqualTo(
      int? mangaIdIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaIdIndex',
              lower: [],
              upper: [mangaIdIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaIdIndex',
              lower: [mangaIdIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaIdIndex',
              lower: [mangaIdIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaIdIndex',
              lower: [],
              upper: [mangaIdIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> mangaIdIndexGreaterThan(
    int? mangaIdIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaIdIndex',
        lower: [mangaIdIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> mangaIdIndexLessThan(
    int? mangaIdIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaIdIndex',
        lower: [],
        upper: [mangaIdIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> mangaIdIndexBetween(
    int? lowerMangaIdIndex,
    int? upperMangaIdIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaIdIndex',
        lower: [lowerMangaIdIndex],
        includeLower: includeLower,
        upper: [upperMangaIdIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> chapterIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'chapterIdIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      chapterIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'chapterIdIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> chapterIdIndexEqualTo(
      int? chapterIdIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'chapterIdIndex',
        value: [chapterIdIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> chapterIdIndexNotEqualTo(
      int? chapterIdIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'chapterIdIndex',
              lower: [],
              upper: [chapterIdIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'chapterIdIndex',
              lower: [chapterIdIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'chapterIdIndex',
              lower: [chapterIdIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'chapterIdIndex',
              lower: [],
              upper: [chapterIdIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> chapterIdIndexGreaterThan(
    int? chapterIdIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'chapterIdIndex',
        lower: [chapterIdIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> chapterIdIndexLessThan(
    int? chapterIdIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'chapterIdIndex',
        lower: [],
        upper: [chapterIdIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> chapterIdIndexBetween(
    int? lowerChapterIdIndex,
    int? upperChapterIdIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'chapterIdIndex',
        lower: [lowerChapterIdIndex],
        includeLower: includeLower,
        upper: [upperChapterIdIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> stateIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'stateIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> stateIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'stateIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> stateIndexEqualTo(
      DownloadState? stateIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'stateIndex',
        value: [stateIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> stateIndexNotEqualTo(
      DownloadState? stateIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateIndex',
              lower: [],
              upper: [stateIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateIndex',
              lower: [stateIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateIndex',
              lower: [stateIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateIndex',
              lower: [],
              upper: [stateIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> priorityIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'priorityIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> priorityIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'priorityIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> priorityIndexEqualTo(
      DownloadPriority? priorityIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'priorityIndex',
        value: [priorityIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> priorityIndexNotEqualTo(
      DownloadPriority? priorityIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'priorityIndex',
              lower: [],
              upper: [priorityIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'priorityIndex',
              lower: [priorityIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'priorityIndex',
              lower: [priorityIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'priorityIndex',
              lower: [],
              upper: [priorityIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> taskIndexIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'taskIndexIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      taskIndexIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'taskIndexIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> taskIndexIndexEqualTo(
      int? taskIndexIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'taskIndexIndex',
        value: [taskIndexIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> taskIndexIndexNotEqualTo(
      int? taskIndexIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'taskIndexIndex',
              lower: [],
              upper: [taskIndexIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'taskIndexIndex',
              lower: [taskIndexIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'taskIndexIndex',
              lower: [taskIndexIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'taskIndexIndex',
              lower: [],
              upper: [taskIndexIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> taskIndexIndexGreaterThan(
    int? taskIndexIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'taskIndexIndex',
        lower: [taskIndexIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> taskIndexIndexLessThan(
    int? taskIndexIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'taskIndexIndex',
        lower: [],
        upper: [taskIndexIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> taskIndexIndexBetween(
    int? lowerTaskIndexIndex,
    int? upperTaskIndexIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'taskIndexIndex',
        lower: [lowerTaskIndexIndex],
        includeLower: includeLower,
        upper: [upperTaskIndexIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> isDownloadedIndexEqualTo(
      bool isDownloadedIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'isDownloadedIndex',
        value: [isDownloadedIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      isDownloadedIndexNotEqualTo(bool isDownloadedIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDownloadedIndex',
              lower: [],
              upper: [isDownloadedIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDownloadedIndex',
              lower: [isDownloadedIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDownloadedIndex',
              lower: [isDownloadedIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDownloadedIndex',
              lower: [],
              upper: [isDownloadedIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> sourceIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'sourceIdIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> sourceIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'sourceIdIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> sourceIdIndexEqualTo(
      String? sourceIdIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'sourceIdIndex',
        value: [sourceIdIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> sourceIdIndexNotEqualTo(
      String? sourceIdIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sourceIdIndex',
              lower: [],
              upper: [sourceIdIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sourceIdIndex',
              lower: [sourceIdIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sourceIdIndex',
              lower: [sourceIdIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sourceIdIndex',
              lower: [],
              upper: [sourceIdIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> mediaTypeIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mediaTypeIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mediaTypeIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mediaTypeIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> mediaTypeIndexEqualTo(
      DownloadMediaType? mediaTypeIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mediaTypeIndex',
        value: [mediaTypeIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> mediaTypeIndexNotEqualTo(
      DownloadMediaType? mediaTypeIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mediaTypeIndex',
              lower: [],
              upper: [mediaTypeIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mediaTypeIndex',
              lower: [mediaTypeIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mediaTypeIndex',
              lower: [mediaTypeIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mediaTypeIndex',
              lower: [],
              upper: [mediaTypeIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> requestedAtIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'requestedAtIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      requestedAtIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'requestedAtIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> requestedAtIndexEqualTo(
      int? requestedAtIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'requestedAtIndex',
        value: [requestedAtIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      requestedAtIndexNotEqualTo(int? requestedAtIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'requestedAtIndex',
              lower: [],
              upper: [requestedAtIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'requestedAtIndex',
              lower: [requestedAtIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'requestedAtIndex',
              lower: [requestedAtIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'requestedAtIndex',
              lower: [],
              upper: [requestedAtIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      requestedAtIndexGreaterThan(
    int? requestedAtIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'requestedAtIndex',
        lower: [requestedAtIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> requestedAtIndexLessThan(
    int? requestedAtIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'requestedAtIndex',
        lower: [],
        upper: [requestedAtIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause> requestedAtIndexBetween(
    int? lowerRequestedAtIndex,
    int? upperRequestedAtIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'requestedAtIndex',
        lower: [lowerRequestedAtIndex],
        includeLower: includeLower,
        upper: [upperRequestedAtIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexIsNullAnyPriorityTaskIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'queueScanIndex_priority_taskIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexIsNotNullAnyPriorityTaskIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'queueScanIndex_priority_taskIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexEqualToAnyPriorityTaskIndex(DownloadState? queueScanIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'queueScanIndex_priority_taskIndex',
        value: [queueScanIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexNotEqualToAnyPriorityTaskIndex(
          DownloadState? queueScanIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [],
              upper: [queueScanIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [queueScanIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [queueScanIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [],
              upper: [queueScanIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexEqualToPriorityIsNullAnyTaskIndex(
          DownloadState? queueScanIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'queueScanIndex_priority_taskIndex',
        value: [queueScanIndex, null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexEqualToPriorityIsNotNullAnyTaskIndex(
          DownloadState? queueScanIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'queueScanIndex_priority_taskIndex',
        lower: [queueScanIndex, null],
        includeLower: false,
        upper: [
          queueScanIndex,
        ],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexPriorityEqualToAnyTaskIndex(
          DownloadState? queueScanIndex, DownloadPriority? priority) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'queueScanIndex_priority_taskIndex',
        value: [queueScanIndex, priority],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexEqualToPriorityNotEqualToAnyTaskIndex(
          DownloadState? queueScanIndex, DownloadPriority? priority) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [queueScanIndex],
              upper: [queueScanIndex, priority],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [queueScanIndex, priority],
              includeLower: false,
              upper: [queueScanIndex],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [queueScanIndex, priority],
              includeLower: false,
              upper: [queueScanIndex],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [queueScanIndex],
              upper: [queueScanIndex, priority],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexPriorityEqualToTaskIndexIsNull(
          DownloadState? queueScanIndex, DownloadPriority? priority) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'queueScanIndex_priority_taskIndex',
        value: [queueScanIndex, priority, null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexPriorityEqualToTaskIndexIsNotNull(
          DownloadState? queueScanIndex, DownloadPriority? priority) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'queueScanIndex_priority_taskIndex',
        lower: [queueScanIndex, priority, null],
        includeLower: false,
        upper: [
          queueScanIndex,
          priority,
        ],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexPriorityTaskIndexEqualTo(DownloadState? queueScanIndex,
          DownloadPriority? priority, int? taskIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'queueScanIndex_priority_taskIndex',
        value: [queueScanIndex, priority, taskIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexPriorityEqualToTaskIndexNotEqualTo(
          DownloadState? queueScanIndex,
          DownloadPriority? priority,
          int? taskIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [queueScanIndex, priority],
              upper: [queueScanIndex, priority, taskIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [queueScanIndex, priority, taskIndex],
              includeLower: false,
              upper: [queueScanIndex, priority],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [queueScanIndex, priority, taskIndex],
              includeLower: false,
              upper: [queueScanIndex, priority],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'queueScanIndex_priority_taskIndex',
              lower: [queueScanIndex, priority],
              upper: [queueScanIndex, priority, taskIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexPriorityEqualToTaskIndexGreaterThan(
    DownloadState? queueScanIndex,
    DownloadPriority? priority,
    int? taskIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'queueScanIndex_priority_taskIndex',
        lower: [queueScanIndex, priority, taskIndex],
        includeLower: include,
        upper: [queueScanIndex, priority],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexPriorityEqualToTaskIndexLessThan(
    DownloadState? queueScanIndex,
    DownloadPriority? priority,
    int? taskIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'queueScanIndex_priority_taskIndex',
        lower: [queueScanIndex, priority],
        upper: [queueScanIndex, priority, taskIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      queueScanIndexPriorityEqualToTaskIndexBetween(
    DownloadState? queueScanIndex,
    DownloadPriority? priority,
    int? lowerTaskIndex,
    int? upperTaskIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'queueScanIndex_priority_taskIndex',
        lower: [queueScanIndex, priority, lowerTaskIndex],
        includeLower: includeLower,
        upper: [queueScanIndex, priority, upperTaskIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexIsNullAnyChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaChapterIndex_chapterId',
        value: [null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexIsNotNullAnyChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexEqualToAnyChapterId(int? mangaChapterIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaChapterIndex_chapterId',
        value: [mangaChapterIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexNotEqualToAnyChapterId(int? mangaChapterIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [],
              upper: [mangaChapterIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [],
              upper: [mangaChapterIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexGreaterThanAnyChapterId(
    int? mangaChapterIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [mangaChapterIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexLessThanAnyChapterId(
    int? mangaChapterIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [],
        upper: [mangaChapterIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexBetweenAnyChapterId(
    int? lowerMangaChapterIndex,
    int? upperMangaChapterIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [lowerMangaChapterIndex],
        includeLower: includeLower,
        upper: [upperMangaChapterIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdIsNull(int? mangaChapterIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaChapterIndex_chapterId',
        value: [mangaChapterIndex, null],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdIsNotNull(int? mangaChapterIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [mangaChapterIndex, null],
        includeLower: false,
        upper: [
          mangaChapterIndex,
        ],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexChapterIdEqualTo(
          int? mangaChapterIndex, int? chapterId) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaChapterIndex_chapterId',
        value: [mangaChapterIndex, chapterId],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdNotEqualTo(
          int? mangaChapterIndex, int? chapterId) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex],
              upper: [mangaChapterIndex, chapterId],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex, chapterId],
              includeLower: false,
              upper: [mangaChapterIndex],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex, chapterId],
              includeLower: false,
              upper: [mangaChapterIndex],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex],
              upper: [mangaChapterIndex, chapterId],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdGreaterThan(
    int? mangaChapterIndex,
    int? chapterId, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [mangaChapterIndex, chapterId],
        includeLower: include,
        upper: [mangaChapterIndex],
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdLessThan(
    int? mangaChapterIndex,
    int? chapterId, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [mangaChapterIndex],
        upper: [mangaChapterIndex, chapterId],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdBetween(
    int? mangaChapterIndex,
    int? lowerChapterId,
    int? upperChapterId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [mangaChapterIndex, lowerChapterId],
        includeLower: includeLower,
        upper: [mangaChapterIndex, upperChapterId],
        includeUpper: includeUpper,
      ));
    });
  }
}

extension DownloadQueryFilter
    on QueryBuilder<Download, Download, QFilterCondition> {
  QueryBuilder<Download, Download, QAfterFilterCondition> audioCodecIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'audioCodec',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      audioCodecIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'audioCodec',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> audioCodecEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'audioCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> audioCodecGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'audioCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> audioCodecLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'audioCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> audioCodecBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'audioCodec',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> audioCodecStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'audioCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> audioCodecEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'audioCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> audioCodecContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'audioCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> audioCodecMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'audioCodec',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> audioCodecIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'audioCodec',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      audioCodecIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'audioCodec',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> categoryIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'categoryId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      categoryIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'categoryId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> categoryIdEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'categoryId',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> categoryIdGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'categoryId',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> categoryIdLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'categoryId',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> categoryIdBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'categoryId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterIdEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterId',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterIdGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterId',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterIdLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterId',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterIdBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterIdIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterIdIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterIdIndexEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterIdIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterIdIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterIdString',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterIdString',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterIdString',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'chapterIdString',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterIdString',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterIdStringIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'chapterIdString',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNameIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterName',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterNameIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterName',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNameEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterNameGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNameLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNameBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterName',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNameStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNameEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNameContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNameMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'chapterName',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNameIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterName',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterNameIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'chapterName',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterNumberIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterNumber',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterNumberIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterNumber',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNumberEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterNumberGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNumberLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNumberBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterNumber',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterNumberStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNumberEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNumberContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chapterNumberMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'chapterNumber',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterNumberIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterNumber',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chapterNumberIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'chapterNumber',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chargingOnlyIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chargingOnly',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      chargingOnlyIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chargingOnly',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> chargingOnlyEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chargingOnly',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> completedAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'completedAt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      completedAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'completedAt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> completedAtEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'completedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      completedAtGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'completedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> completedAtLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'completedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> completedAtBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'completedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'containerFormat',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'containerFormat',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'containerFormat',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'containerFormat',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'containerFormat',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'containerFormat',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'containerFormat',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'containerFormat',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'containerFormat',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'containerFormat',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'containerFormat',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      containerFormatIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'containerFormat',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      deleteAfterReadIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'deleteAfterRead',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      deleteAfterReadIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'deleteAfterRead',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      deleteAfterReadEqualTo(bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'deleteAfterRead',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'deviceId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'deviceId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'deviceId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'deviceId',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'deviceId',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> deviceIdIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'deviceId',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadDirIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'downloadDir',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadDirIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'downloadDir',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadDirEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'downloadDir',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadDirGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'downloadDir',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadDirLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'downloadDir',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadDirBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'downloadDir',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadDirStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'downloadDir',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadDirEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'downloadDir',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadDirContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'downloadDir',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadDirMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'downloadDir',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadDirIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'downloadDir',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadDirIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'downloadDir',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadPathIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'downloadPath',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadPathIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'downloadPath',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadPathEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'downloadPath',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadPathGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'downloadPath',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadPathLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'downloadPath',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadPathBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'downloadPath',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadPathStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'downloadPath',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadPathEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'downloadPath',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadPathContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'downloadPath',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> downloadPathMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'downloadPath',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadPathIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'downloadPath',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadPathIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'downloadPath',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadedBytesIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'downloadedBytes',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadedBytesIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'downloadedBytes',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadedBytesEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'downloadedBytes',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadedBytesGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'downloadedBytes',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadedBytesLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'downloadedBytes',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      downloadedBytesBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'downloadedBytes',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> encryptIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'encrypt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> encryptIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'encrypt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> encryptEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'encrypt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      encryptionKeyIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'encryptionKey',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      encryptionKeyIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'encryptionKey',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> encryptionKeyEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'encryptionKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      encryptionKeyGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'encryptionKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> encryptionKeyLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'encryptionKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> encryptionKeyBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'encryptionKey',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      encryptionKeyStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'encryptionKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> encryptionKeyEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'encryptionKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> encryptionKeyContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'encryptionKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> encryptionKeyMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'encryptionKey',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      encryptionKeyIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'encryptionKey',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      encryptionKeyIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'encryptionKey',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> failedIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'failed',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> failedIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'failed',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> failedEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'failed',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> failedGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'failed',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> failedLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'failed',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> failedBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'failed',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      fileExtensionIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'fileExtension',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      fileExtensionIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'fileExtension',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileExtensionEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'fileExtension',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      fileExtensionGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'fileExtension',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileExtensionLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'fileExtension',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileExtensionBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'fileExtension',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      fileExtensionStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'fileExtension',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileExtensionEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'fileExtension',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileExtensionContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'fileExtension',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileExtensionMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'fileExtension',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      fileExtensionIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'fileExtension',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      fileExtensionIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'fileExtension',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileSizeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'fileSize',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileSizeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'fileSize',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileSizeEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'fileSize',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileSizeGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'fileSize',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileSizeLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'fileSize',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> fileSizeBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'fileSize',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> hashCodeEqualTo(
      int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'hashCode',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> hashCodeGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'hashCode',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> hashCodeLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'hashCode',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> hashCodeBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'hashCode',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> headersJsonIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'headersJson',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'headersJson',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonElementEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'headersJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'headersJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'headersJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'headersJson',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonElementStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'headersJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonElementEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'headersJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonElementContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'headersJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonElementMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'headersJson',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'headersJson',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'headersJson',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonLengthEqualTo(int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'headersJson',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> headersJsonIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'headersJson',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'headersJson',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'headersJson',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'headersJson',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      headersJsonLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'headersJson',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> idEqualTo(Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isAnimeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isAnime',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isAnimeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isAnime',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isAnimeEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isAnime',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isBookIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isBook',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isBookIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isBook',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isBookEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isBook',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isDownloadedIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isDownloaded',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      isDownloadedIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isDownloaded',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isDownloadedEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isDownloaded',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      isDownloadedIndexEqualTo(bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isDownloadedIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isMangaIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isManga',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isMangaIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isManga',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isMangaEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isManga',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      isPauseDownloadIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isPauseDownload',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      isPauseDownloadIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isPauseDownload',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      isPauseDownloadEqualTo(bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isPauseDownload',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      isStartDownloadIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isStartDownload',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      isStartDownloadIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isStartDownload',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      isStartDownloadEqualTo(bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isStartDownload',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      isStopDownloadIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isStopDownload',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      isStopDownloadIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isStopDownload',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isStopDownloadEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isStopDownload',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isSyncedIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isSynced',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isSyncedIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isSynced',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> isSyncedEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isSynced',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'lastError',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'lastError',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'lastError',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'lastError',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'lastError',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'lastError',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'lastError',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'lastError',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'lastError',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'lastError',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastErrorIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'lastError',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastErrorIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'lastError',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastStackTraceIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'lastStackTrace',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastStackTraceIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'lastStackTrace',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastStackTraceEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'lastStackTrace',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastStackTraceGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'lastStackTrace',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastStackTraceLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'lastStackTrace',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastStackTraceBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'lastStackTrace',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastStackTraceStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'lastStackTrace',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastStackTraceEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'lastStackTrace',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastStackTraceContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'lastStackTrace',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastStackTraceMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'lastStackTrace',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastStackTraceIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'lastStackTrace',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastStackTraceIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'lastStackTrace',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastSyncedAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'lastSyncedAt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastSyncedAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'lastSyncedAt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastSyncedAtEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'lastSyncedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      lastSyncedAtGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'lastSyncedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastSyncedAtLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'lastSyncedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> lastSyncedAtBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'lastSyncedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaChapterIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaChapterIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaChapterIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaChapterIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaChapterIndexEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaChapterIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaChapterIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaChapterIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaChapterIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaChapterIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaChapterIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaChapterIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaCoverIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaCover',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaCoverIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaCover',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaCoverEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaCoverGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaCoverLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaCoverBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaCover',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaCoverStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaCoverEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaCoverContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaCoverMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mangaCover',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaCoverIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaCover',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaCoverIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mangaCover',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaId',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaId',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaId',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaIdIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaIdIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdIndexEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaIdIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaIdIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaIdStringIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaIdString',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaIdStringIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaIdString',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdStringEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaIdStringGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdStringLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdStringBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaIdString',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaIdStringStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdStringEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdStringContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaIdStringMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mangaIdString',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaIdStringIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaIdString',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaIdStringIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mangaIdString',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaTitleIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaTitle',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaTitleIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaTitle',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaTitleEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaTitleGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaTitleLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaTitleBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaTitle',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaTitleStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaTitleEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaTitleContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaTitleMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mangaTitle',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mangaTitleIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaTitle',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mangaTitleIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mangaTitle',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> maxRetriesIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'maxRetries',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      maxRetriesIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'maxRetries',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> maxRetriesEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'maxRetries',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> maxRetriesGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'maxRetries',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> maxRetriesLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'maxRetries',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> maxRetriesBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'maxRetries',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mediaType',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mediaType',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeEqualTo(
    DownloadMediaType? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeGreaterThan(
    DownloadMediaType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeLessThan(
    DownloadMediaType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeBetween(
    DownloadMediaType? lower,
    DownloadMediaType? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mediaType',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mediaType',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mediaType',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mediaTypeIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mediaType',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mediaTypeIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mediaTypeIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mediaTypeIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mediaTypeIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeIndexEqualTo(
    DownloadMediaType? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mediaTypeIndexGreaterThan(
    DownloadMediaType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mediaTypeIndexLessThan(
    DownloadMediaType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeIndexBetween(
    DownloadMediaType? lower,
    DownloadMediaType? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mediaTypeIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mediaTypeIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mediaTypeIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mediaTypeIndexContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mediaTypeIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mediaTypeIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mediaTypeIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mediaTypeIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      mediaTypeIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mediaTypeIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mimeType',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mimeType',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mimeType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mimeType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mimeType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mimeType',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mimeType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mimeType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mimeType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mimeType',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mimeType',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> mimeTypeIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mimeType',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'note',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'note',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'note',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'note',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'note',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> noteIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'note',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'password',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'password',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'password',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'password',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'password',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'password',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'password',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'password',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'password',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'password',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'password',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> passwordIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'password',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'priority',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'priority',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityEqualTo(
    DownloadPriority? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'priority',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityGreaterThan(
    DownloadPriority? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'priority',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityLessThan(
    DownloadPriority? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'priority',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityBetween(
    DownloadPriority? lower,
    DownloadPriority? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'priority',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'priority',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'priority',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'priority',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'priority',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'priority',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'priority',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      priorityIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'priorityIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      priorityIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'priorityIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityIndexEqualTo(
    DownloadPriority? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'priorityIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      priorityIndexGreaterThan(
    DownloadPriority? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'priorityIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityIndexLessThan(
    DownloadPriority? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'priorityIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityIndexBetween(
    DownloadPriority? lower,
    DownloadPriority? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'priorityIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      priorityIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'priorityIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'priorityIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityIndexContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'priorityIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> priorityIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'priorityIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      priorityIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'priorityIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      priorityIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'priorityIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      queueScanIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'queueScanIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      queueScanIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'queueScanIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> queueScanIndexEqualTo(
    DownloadState? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'queueScanIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      queueScanIndexGreaterThan(
    DownloadState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'queueScanIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      queueScanIndexLessThan(
    DownloadState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'queueScanIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> queueScanIndexBetween(
    DownloadState? lower,
    DownloadState? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'queueScanIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      queueScanIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'queueScanIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      queueScanIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'queueScanIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      queueScanIndexContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'queueScanIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> queueScanIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'queueScanIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      queueScanIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'queueScanIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      queueScanIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'queueScanIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'referer',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'referer',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'referer',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'referer',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'referer',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'referer',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'referer',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'referer',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'referer',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'referer',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'referer',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> refererIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'referer',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> requestedAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'requestedAt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      requestedAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'requestedAt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> requestedAtEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'requestedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      requestedAtGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'requestedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> requestedAtLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'requestedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> requestedAtBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'requestedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      requestedAtIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'requestedAtIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      requestedAtIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'requestedAtIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      requestedAtIndexEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'requestedAtIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      requestedAtIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'requestedAtIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      requestedAtIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'requestedAtIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      requestedAtIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'requestedAtIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> retryCountIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'retryCount',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      retryCountIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'retryCount',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> retryCountEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'retryCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> retryCountGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'retryCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> retryCountLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'retryCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> retryCountBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'retryCount',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> revisionIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'revision',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> revisionIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'revision',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> revisionEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'revision',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> revisionGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'revision',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> revisionLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'revision',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> revisionBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'revision',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> savedFilesIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'savedFiles',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'savedFiles',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesElementEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'savedFiles',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'savedFiles',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'savedFiles',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'savedFiles',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesElementStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'savedFiles',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesElementEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'savedFiles',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesElementContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'savedFiles',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesElementMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'savedFiles',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'savedFiles',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'savedFiles',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesLengthEqualTo(int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'savedFiles',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> savedFilesIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'savedFiles',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'savedFiles',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'savedFiles',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'savedFiles',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      savedFilesLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'savedFiles',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'sourceId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'sourceId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'sourceId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'sourceId',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sourceId',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'sourceId',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      sourceIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'sourceIdIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      sourceIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'sourceIdIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdIndexEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      sourceIdIndexGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdIndexLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdIndexBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'sourceIdIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      sourceIdIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdIndexContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> sourceIdIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'sourceIdIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      sourceIdIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sourceIdIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      sourceIdIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'sourceIdIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> startedAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'startedAt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> startedAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'startedAt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> startedAtEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'startedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> startedAtGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'startedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> startedAtLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'startedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> startedAtBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'startedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'state',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'state',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateEqualTo(
    DownloadState? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateGreaterThan(
    DownloadState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateLessThan(
    DownloadState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateBetween(
    DownloadState? lower,
    DownloadState? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'state',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'state',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'state',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'state',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'stateIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      stateIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'stateIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIndexEqualTo(
    DownloadState? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIndexGreaterThan(
    DownloadState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIndexLessThan(
    DownloadState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIndexBetween(
    DownloadState? lower,
    DownloadState? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'stateIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIndexContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'stateIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> stateIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'stateIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      stateIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'stateIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> successIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'success',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> successIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'success',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> successEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'success',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> successGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'success',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> successLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'success',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> successBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'success',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'tags',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'tags',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsElementEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      tagsElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'tags',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsElementStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsElementEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsElementContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsElementMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'tags',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'tags',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      tagsElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'tags',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsLengthEqualTo(
      int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> tagsLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'taskId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'taskId',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'taskId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'taskId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'taskId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'taskId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'taskId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'taskId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'taskId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'taskId',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'taskId',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIdIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'taskId',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'taskIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'taskIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIndexEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'taskIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'taskIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'taskIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'taskIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      taskIndexIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'taskIndexIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      taskIndexIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'taskIndexIndex',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIndexIndexEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'taskIndexIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      taskIndexIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'taskIndexIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      taskIndexIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'taskIndexIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> taskIndexIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'taskIndexIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> totalIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'total',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> totalIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'total',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> totalEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'total',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> totalGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'total',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> totalLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'total',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> totalBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'total',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> updatedAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'updatedAt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> updatedAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'updatedAt',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> updatedAtEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> updatedAtGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> updatedAtLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> updatedAtBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'updatedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'url',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'url',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'url',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'url',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'url',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'url',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'urls',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'urls',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsElementEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'urls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      urlsElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'urls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'urls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'urls',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsElementStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'urls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsElementEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'urls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsElementContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'urls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsElementMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'urls',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'urls',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      urlsElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'urls',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsLengthEqualTo(
      int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'urls',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'urls',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'urls',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'urls',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'urls',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> urlsLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'urls',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'username',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'username',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'username',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'username',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'username',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'username',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'username',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'username',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'username',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'username',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'username',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> usernameIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'username',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoBitrateIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'videoBitrate',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoBitrateIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'videoBitrate',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoBitrateEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'videoBitrate',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoBitrateGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'videoBitrate',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoBitrateLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'videoBitrate',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoBitrateBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'videoBitrate',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoCodecIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'videoCodec',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoCodecIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'videoCodec',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoCodecEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'videoCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoCodecGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'videoCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoCodecLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'videoCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoCodecBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'videoCodec',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoCodecStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'videoCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoCodecEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'videoCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoCodecContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'videoCodec',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoCodecMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'videoCodec',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoCodecIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'videoCodec',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoCodecIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'videoCodec',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoDurationIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'videoDuration',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoDurationIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'videoDuration',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoDurationEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'videoDuration',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoDurationGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'videoDuration',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoDurationLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'videoDuration',
        value: value,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoDurationBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'videoDuration',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoQualityIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'videoQuality',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoQualityIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'videoQuality',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoQualityEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'videoQuality',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoQualityGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'videoQuality',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoQualityLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'videoQuality',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoQualityBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'videoQuality',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoQualityStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'videoQuality',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoQualityEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'videoQuality',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoQualityContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'videoQuality',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> videoQualityMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'videoQuality',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoQualityIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'videoQuality',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition>
      videoQualityIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'videoQuality',
        value: '',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> wifiOnlyIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'wifiOnly',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> wifiOnlyIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'wifiOnly',
      ));
    });
  }

  QueryBuilder<Download, Download, QAfterFilterCondition> wifiOnlyEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'wifiOnly',
        value: value,
      ));
    });
  }
}

extension DownloadQueryObject
    on QueryBuilder<Download, Download, QFilterCondition> {}

extension DownloadQueryLinks
    on QueryBuilder<Download, Download, QFilterCondition> {}

extension DownloadQuerySortBy on QueryBuilder<Download, Download, QSortBy> {
  QueryBuilder<Download, Download, QAfterSortBy> sortByAudioCodec() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'audioCodec', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByAudioCodecDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'audioCodec', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByCategoryId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'categoryId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByCategoryIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'categoryId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChapterIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChapterIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChapterIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChapterIdString() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdString', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChapterIdStringDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdString', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChapterName() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterName', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChapterNameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterName', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChapterNumber() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumber', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChapterNumberDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumber', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChargingOnly() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chargingOnly', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByChargingOnlyDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chargingOnly', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByCompletedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'completedAt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByCompletedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'completedAt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByContainerFormat() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'containerFormat', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByContainerFormatDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'containerFormat', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByDeleteAfterRead() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deleteAfterRead', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByDeleteAfterReadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deleteAfterRead', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByDeviceId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deviceId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByDeviceIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deviceId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByDownloadDir() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadDir', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByDownloadDirDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadDir', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByDownloadPath() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadPath', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByDownloadPathDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadPath', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByDownloadedBytes() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadedBytes', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByDownloadedBytesDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadedBytes', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByEncrypt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'encrypt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByEncryptDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'encrypt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByEncryptionKey() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'encryptionKey', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByEncryptionKeyDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'encryptionKey', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByFailed() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'failed', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByFailedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'failed', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByFileExtension() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileExtension', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByFileExtensionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileExtension', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByFileSize() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileSize', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByFileSizeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileSize', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByHashCode() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hashCode', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByHashCodeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hashCode', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsAnime() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAnime', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsAnimeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAnime', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsBook() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBook', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsBookDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBook', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsDownloaded() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloaded', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsDownloadedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloaded', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsDownloadedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloadedIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsDownloadedIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloadedIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsManga() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isManga', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsMangaDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isManga', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsPauseDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isPauseDownload', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsPauseDownloadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isPauseDownload', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsStartDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isStartDownload', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsStartDownloadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isStartDownload', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsStopDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isStopDownload', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsStopDownloadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isStopDownload', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsSynced() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSynced', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByIsSyncedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSynced', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByLastError() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastError', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByLastErrorDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastError', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByLastStackTrace() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastStackTrace', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByLastStackTraceDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastStackTrace', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByLastSyncedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastSyncedAt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByLastSyncedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastSyncedAt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaChapterIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaChapterIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaChapterIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaChapterIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaCover() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaCover', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaCoverDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaCover', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaIdString() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdString', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaIdStringDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdString', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaTitle() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaTitle', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMangaTitleDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaTitle', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMaxRetries() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'maxRetries', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMaxRetriesDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'maxRetries', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMediaType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaType', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMediaTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaType', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMediaTypeIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaTypeIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMediaTypeIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaTypeIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMimeType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mimeType', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByMimeTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mimeType', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByNote() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByNoteDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByPassword() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'password', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByPasswordDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'password', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByPriority() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'priority', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByPriorityDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'priority', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByPriorityIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'priorityIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByPriorityIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'priorityIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByQueueScanIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'queueScanIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByQueueScanIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'queueScanIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByReferer() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'referer', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByRefererDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'referer', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByRequestedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'requestedAt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByRequestedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'requestedAt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByRequestedAtIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'requestedAtIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByRequestedAtIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'requestedAtIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByRetryCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'retryCount', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByRetryCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'retryCount', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByRevision() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'revision', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByRevisionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'revision', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortBySourceId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortBySourceIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortBySourceIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortBySourceIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByStartedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'startedAt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByStartedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'startedAt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByState() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'state', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByStateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'state', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByStateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByStateIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortBySuccess() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'success', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortBySuccessDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'success', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByTaskId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByTaskIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByTaskIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByTaskIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByTaskIndexIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskIndexIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByTaskIndexIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskIndexIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByTotal() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'total', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByTotalDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'total', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByUrl() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'url', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByUrlDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'url', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByUsername() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'username', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByUsernameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'username', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByVideoBitrate() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoBitrate', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByVideoBitrateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoBitrate', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByVideoCodec() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoCodec', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByVideoCodecDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoCodec', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByVideoDuration() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoDuration', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByVideoDurationDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoDuration', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByVideoQuality() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoQuality', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByVideoQualityDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoQuality', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByWifiOnly() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'wifiOnly', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> sortByWifiOnlyDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'wifiOnly', Sort.desc);
    });
  }
}

extension DownloadQuerySortThenBy
    on QueryBuilder<Download, Download, QSortThenBy> {
  QueryBuilder<Download, Download, QAfterSortBy> thenByAudioCodec() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'audioCodec', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByAudioCodecDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'audioCodec', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByCategoryId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'categoryId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByCategoryIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'categoryId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChapterIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChapterIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChapterIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChapterIdString() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdString', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChapterIdStringDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdString', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChapterName() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterName', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChapterNameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterName', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChapterNumber() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumber', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChapterNumberDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumber', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChargingOnly() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chargingOnly', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByChargingOnlyDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chargingOnly', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByCompletedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'completedAt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByCompletedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'completedAt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByContainerFormat() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'containerFormat', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByContainerFormatDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'containerFormat', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByDeleteAfterRead() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deleteAfterRead', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByDeleteAfterReadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deleteAfterRead', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByDeviceId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deviceId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByDeviceIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deviceId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByDownloadDir() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadDir', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByDownloadDirDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadDir', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByDownloadPath() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadPath', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByDownloadPathDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadPath', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByDownloadedBytes() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadedBytes', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByDownloadedBytesDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'downloadedBytes', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByEncrypt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'encrypt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByEncryptDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'encrypt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByEncryptionKey() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'encryptionKey', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByEncryptionKeyDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'encryptionKey', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByFailed() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'failed', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByFailedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'failed', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByFileExtension() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileExtension', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByFileExtensionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileExtension', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByFileSize() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileSize', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByFileSizeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileSize', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByHashCode() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hashCode', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByHashCodeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hashCode', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsAnime() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAnime', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsAnimeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAnime', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsBook() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBook', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsBookDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBook', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsDownloaded() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloaded', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsDownloadedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloaded', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsDownloadedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloadedIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsDownloadedIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloadedIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsManga() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isManga', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsMangaDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isManga', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsPauseDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isPauseDownload', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsPauseDownloadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isPauseDownload', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsStartDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isStartDownload', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsStartDownloadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isStartDownload', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsStopDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isStopDownload', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsStopDownloadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isStopDownload', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsSynced() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSynced', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByIsSyncedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSynced', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByLastError() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastError', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByLastErrorDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastError', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByLastStackTrace() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastStackTrace', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByLastStackTraceDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastStackTrace', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByLastSyncedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastSyncedAt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByLastSyncedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastSyncedAt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaChapterIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaChapterIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaChapterIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaChapterIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaCover() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaCover', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaCoverDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaCover', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaIdString() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdString', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaIdStringDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdString', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaTitle() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaTitle', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMangaTitleDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaTitle', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMaxRetries() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'maxRetries', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMaxRetriesDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'maxRetries', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMediaType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaType', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMediaTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaType', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMediaTypeIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaTypeIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMediaTypeIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaTypeIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMimeType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mimeType', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByMimeTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mimeType', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByNote() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByNoteDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByPassword() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'password', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByPasswordDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'password', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByPriority() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'priority', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByPriorityDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'priority', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByPriorityIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'priorityIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByPriorityIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'priorityIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByQueueScanIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'queueScanIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByQueueScanIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'queueScanIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByReferer() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'referer', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByRefererDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'referer', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByRequestedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'requestedAt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByRequestedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'requestedAt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByRequestedAtIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'requestedAtIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByRequestedAtIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'requestedAtIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByRetryCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'retryCount', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByRetryCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'retryCount', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByRevision() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'revision', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByRevisionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'revision', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenBySourceId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenBySourceIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenBySourceIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenBySourceIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByStartedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'startedAt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByStartedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'startedAt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByState() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'state', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByStateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'state', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByStateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByStateIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenBySuccess() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'success', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenBySuccessDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'success', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByTaskId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskId', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByTaskIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskId', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByTaskIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByTaskIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByTaskIndexIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskIndexIndex', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByTaskIndexIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'taskIndexIndex', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByTotal() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'total', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByTotalDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'total', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByUrl() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'url', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByUrlDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'url', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByUsername() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'username', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByUsernameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'username', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByVideoBitrate() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoBitrate', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByVideoBitrateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoBitrate', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByVideoCodec() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoCodec', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByVideoCodecDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoCodec', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByVideoDuration() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoDuration', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByVideoDurationDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoDuration', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByVideoQuality() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoQuality', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByVideoQualityDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoQuality', Sort.desc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByWifiOnly() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'wifiOnly', Sort.asc);
    });
  }

  QueryBuilder<Download, Download, QAfterSortBy> thenByWifiOnlyDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'wifiOnly', Sort.desc);
    });
  }
}

extension DownloadQueryWhereDistinct
    on QueryBuilder<Download, Download, QDistinct> {
  QueryBuilder<Download, Download, QDistinct> distinctByAudioCodec(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'audioCodec', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByCategoryId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'categoryId');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterId');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByChapterIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterIdIndex');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByChapterIdString(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterIdString',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByChapterName(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterName', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByChapterNumber(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterNumber',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByChargingOnly() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chargingOnly');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByCompletedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'completedAt');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByContainerFormat(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'containerFormat',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByDeleteAfterRead() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'deleteAfterRead');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByDeviceId(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'deviceId', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByDownloadDir(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'downloadDir', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByDownloadPath(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'downloadPath', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByDownloadedBytes() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'downloadedBytes');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByEncrypt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'encrypt');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByEncryptionKey(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'encryptionKey',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByFailed() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'failed');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByFileExtension(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'fileExtension',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByFileSize() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'fileSize');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByHashCode() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'hashCode');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByHeadersJson() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'headersJson');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByIsAnime() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isAnime');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByIsBook() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isBook');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByIsDownloaded() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isDownloaded');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByIsDownloadedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isDownloadedIndex');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByIsManga() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isManga');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByIsPauseDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isPauseDownload');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByIsStartDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isStartDownload');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByIsStopDownload() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isStopDownload');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByIsSynced() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isSynced');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByLastError(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'lastError', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByLastStackTrace(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'lastStackTrace',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByLastSyncedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'lastSyncedAt');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByMangaChapterIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaChapterIndex');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByMangaCover(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaCover', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByMangaId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaId');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByMangaIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaIdIndex');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByMangaIdString(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaIdString',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByMangaTitle(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaTitle', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByMaxRetries() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'maxRetries');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByMediaType(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mediaType', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByMediaTypeIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mediaTypeIndex',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByMimeType(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mimeType', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByNote(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'note', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByPassword(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'password', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByPriority(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'priority', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByPriorityIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'priorityIndex',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByQueueScanIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'queueScanIndex',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByReferer(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'referer', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByRequestedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'requestedAt');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByRequestedAtIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'requestedAtIndex');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByRetryCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'retryCount');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByRevision() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'revision');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctBySavedFiles() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'savedFiles');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctBySourceId(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'sourceId', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctBySourceIdIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'sourceIdIndex',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByStartedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'startedAt');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByState(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'state', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByStateIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'stateIndex', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctBySuccess() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'success');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByTags() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'tags');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByTaskId(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'taskId', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByTaskIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'taskIndex');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByTaskIndexIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'taskIndexIndex');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByTotal() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'total');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'updatedAt');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByUrl(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'url', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByUrls() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'urls');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByUsername(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'username', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByVideoBitrate() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'videoBitrate');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByVideoCodec(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'videoCodec', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByVideoDuration() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'videoDuration');
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByVideoQuality(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'videoQuality', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Download, Download, QDistinct> distinctByWifiOnly() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'wifiOnly');
    });
  }
}

extension DownloadQueryProperty
    on QueryBuilder<Download, Download, QQueryProperty> {
  QueryBuilder<Download, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> audioCodecProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'audioCodec');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> categoryIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'categoryId');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> chapterIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterId');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> chapterIdIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterIdIndex');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> chapterIdStringProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterIdString');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> chapterNameProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterName');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> chapterNumberProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterNumber');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> chargingOnlyProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chargingOnly');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> completedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'completedAt');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> containerFormatProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'containerFormat');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> deleteAfterReadProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'deleteAfterRead');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> deviceIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'deviceId');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> downloadDirProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'downloadDir');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> downloadPathProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'downloadPath');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> downloadedBytesProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'downloadedBytes');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> encryptProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'encrypt');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> encryptionKeyProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'encryptionKey');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> failedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'failed');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> fileExtensionProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'fileExtension');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> fileSizeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'fileSize');
    });
  }

  QueryBuilder<Download, int, QQueryOperations> hashCodeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'hashCode');
    });
  }

  QueryBuilder<Download, List<String>?, QQueryOperations>
      headersJsonProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'headersJson');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> isAnimeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isAnime');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> isBookProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isBook');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> isDownloadedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isDownloaded');
    });
  }

  QueryBuilder<Download, bool, QQueryOperations> isDownloadedIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isDownloadedIndex');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> isMangaProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isManga');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> isPauseDownloadProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isPauseDownload');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> isStartDownloadProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isStartDownload');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> isStopDownloadProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isStopDownload');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> isSyncedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isSynced');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> lastErrorProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'lastError');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> lastStackTraceProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'lastStackTrace');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> lastSyncedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'lastSyncedAt');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> mangaChapterIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaChapterIndex');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> mangaCoverProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaCover');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> mangaIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaId');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> mangaIdIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaIdIndex');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> mangaIdStringProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaIdString');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> mangaTitleProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaTitle');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> maxRetriesProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'maxRetries');
    });
  }

  QueryBuilder<Download, DownloadMediaType?, QQueryOperations>
      mediaTypeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mediaType');
    });
  }

  QueryBuilder<Download, DownloadMediaType?, QQueryOperations>
      mediaTypeIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mediaTypeIndex');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> mimeTypeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mimeType');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> noteProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'note');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> passwordProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'password');
    });
  }

  QueryBuilder<Download, DownloadPriority?, QQueryOperations>
      priorityProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'priority');
    });
  }

  QueryBuilder<Download, DownloadPriority?, QQueryOperations>
      priorityIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'priorityIndex');
    });
  }

  QueryBuilder<Download, DownloadState?, QQueryOperations>
      queueScanIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'queueScanIndex');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> refererProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'referer');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> requestedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'requestedAt');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> requestedAtIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'requestedAtIndex');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> retryCountProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'retryCount');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> revisionProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'revision');
    });
  }

  QueryBuilder<Download, List<String>?, QQueryOperations> savedFilesProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'savedFiles');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> sourceIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'sourceId');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> sourceIdIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'sourceIdIndex');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> startedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'startedAt');
    });
  }

  QueryBuilder<Download, DownloadState?, QQueryOperations> stateProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'state');
    });
  }

  QueryBuilder<Download, DownloadState?, QQueryOperations>
      stateIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'stateIndex');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> successProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'success');
    });
  }

  QueryBuilder<Download, List<String>?, QQueryOperations> tagsProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'tags');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> taskIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'taskId');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> taskIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'taskIndex');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> taskIndexIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'taskIndexIndex');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> totalProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'total');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> updatedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'updatedAt');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> urlProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'url');
    });
  }

  QueryBuilder<Download, List<String>?, QQueryOperations> urlsProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'urls');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> usernameProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'username');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> videoBitrateProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'videoBitrate');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> videoCodecProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'videoCodec');
    });
  }

  QueryBuilder<Download, int?, QQueryOperations> videoDurationProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'videoDuration');
    });
  }

  QueryBuilder<Download, String?, QQueryOperations> videoQualityProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'videoQuality');
    });
  }

  QueryBuilder<Download, bool?, QQueryOperations> wifiOnlyProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'wifiOnly');
    });
  }
}
