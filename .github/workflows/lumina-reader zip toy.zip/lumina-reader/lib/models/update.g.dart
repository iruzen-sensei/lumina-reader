// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetUpdateCollection on Isar {
  IsarCollection<Update> get updates => this.collection();
}

const UpdateSchema = CollectionSchema(
  name: r'Update',
  id: -8192355249181452821,
  properties: {
    r'categoryId': PropertySchema(
      id: 0,
      name: r'categoryId',
      type: IsarType.long,
    ),
    r'chapterId': PropertySchema(
      id: 1,
      name: r'chapterId',
      type: IsarType.long,
    ),
    r'chapterIdIndex': PropertySchema(
      id: 2,
      name: r'chapterIdIndex',
      type: IsarType.long,
    ),
    r'chapterIdString': PropertySchema(
      id: 3,
      name: r'chapterIdString',
      type: IsarType.string,
    ),
    r'chapterName': PropertySchema(
      id: 4,
      name: r'chapterName',
      type: IsarType.string,
    ),
    r'chapterNumber': PropertySchema(
      id: 5,
      name: r'chapterNumber',
      type: IsarType.string,
    ),
    r'chapterNumberValue': PropertySchema(
      id: 6,
      name: r'chapterNumberValue',
      type: IsarType.double,
    ),
    r'date': PropertySchema(
      id: 7,
      name: r'date',
      type: IsarType.long,
    ),
    r'dateIndex': PropertySchema(
      id: 8,
      name: r'dateIndex',
      type: IsarType.long,
    ),
    r'deviceId': PropertySchema(
      id: 9,
      name: r'deviceId',
      type: IsarType.string,
    ),
    r'discoveredAt': PropertySchema(
      id: 10,
      name: r'discoveredAt',
      type: IsarType.long,
    ),
    r'discoveredAtIndex': PropertySchema(
      id: 11,
      name: r'discoveredAtIndex',
      type: IsarType.long,
    ),
    r'effectiveChapterNumber': PropertySchema(
      id: 12,
      name: r'effectiveChapterNumber',
      type: IsarType.double,
    ),
    r'fileSize': PropertySchema(
      id: 13,
      name: r'fileSize',
      type: IsarType.long,
    ),
    r'hashCode': PropertySchema(
      id: 14,
      name: r'hashCode',
      type: IsarType.long,
    ),
    r'isAnime': PropertySchema(
      id: 15,
      name: r'isAnime',
      type: IsarType.bool,
    ),
    r'isBook': PropertySchema(
      id: 16,
      name: r'isBook',
      type: IsarType.bool,
    ),
    r'isBookmarked': PropertySchema(
      id: 17,
      name: r'isBookmarked',
      type: IsarType.bool,
    ),
    r'isBookmarkedIndex': PropertySchema(
      id: 18,
      name: r'isBookmarkedIndex',
      type: IsarType.bool,
    ),
    r'isDismissed': PropertySchema(
      id: 19,
      name: r'isDismissed',
      type: IsarType.bool,
    ),
    r'isDownloaded': PropertySchema(
      id: 20,
      name: r'isDownloaded',
      type: IsarType.bool,
    ),
    r'isDownloadedIndex': PropertySchema(
      id: 21,
      name: r'isDownloadedIndex',
      type: IsarType.bool,
    ),
    r'isFresh': PropertySchema(
      id: 22,
      name: r'isFresh',
      type: IsarType.bool,
    ),
    r'isManga': PropertySchema(
      id: 23,
      name: r'isManga',
      type: IsarType.bool,
    ),
    r'isRead': PropertySchema(
      id: 24,
      name: r'isRead',
      type: IsarType.bool,
    ),
    r'isReadIndex': PropertySchema(
      id: 25,
      name: r'isReadIndex',
      type: IsarType.bool,
    ),
    r'isSeen': PropertySchema(
      id: 26,
      name: r'isSeen',
      type: IsarType.bool,
    ),
    r'isSeenIndex': PropertySchema(
      id: 27,
      name: r'isSeenIndex',
      type: IsarType.bool,
    ),
    r'isSynced': PropertySchema(
      id: 28,
      name: r'isSynced',
      type: IsarType.bool,
    ),
    r'isSyncedIndex': PropertySchema(
      id: 29,
      name: r'isSyncedIndex',
      type: IsarType.bool,
    ),
    r'language': PropertySchema(
      id: 30,
      name: r'language',
      type: IsarType.string,
    ),
    r'lastSyncedAt': PropertySchema(
      id: 31,
      name: r'lastSyncedAt',
      type: IsarType.long,
    ),
    r'mangaChapterIndex': PropertySchema(
      id: 32,
      name: r'mangaChapterIndex',
      type: IsarType.long,
    ),
    r'mangaCover': PropertySchema(
      id: 33,
      name: r'mangaCover',
      type: IsarType.string,
    ),
    r'mangaDateIndex': PropertySchema(
      id: 34,
      name: r'mangaDateIndex',
      type: IsarType.long,
    ),
    r'mangaId': PropertySchema(
      id: 35,
      name: r'mangaId',
      type: IsarType.long,
    ),
    r'mangaIdIndex': PropertySchema(
      id: 36,
      name: r'mangaIdIndex',
      type: IsarType.long,
    ),
    r'mangaIdString': PropertySchema(
      id: 37,
      name: r'mangaIdString',
      type: IsarType.string,
    ),
    r'mangaTitle': PropertySchema(
      id: 38,
      name: r'mangaTitle',
      type: IsarType.string,
    ),
    r'mediaType': PropertySchema(
      id: 39,
      name: r'mediaType',
      type: IsarType.string,
      enumMap: _UpdatemediaTypeEnumValueMap,
    ),
    r'mediaTypeIndex': PropertySchema(
      id: 40,
      name: r'mediaTypeIndex',
      type: IsarType.string,
      enumMap: _UpdatemediaTypeIndexEnumValueMap,
    ),
    r'metadataJson': PropertySchema(
      id: 41,
      name: r'metadataJson',
      type: IsarType.string,
    ),
    r'note': PropertySchema(
      id: 42,
      name: r'note',
      type: IsarType.string,
    ),
    r'pageCount': PropertySchema(
      id: 43,
      name: r'pageCount',
      type: IsarType.long,
    ),
    r'previewUrls': PropertySchema(
      id: 44,
      name: r'previewUrls',
      type: IsarType.stringList,
    ),
    r'revision': PropertySchema(
      id: 45,
      name: r'revision',
      type: IsarType.long,
    ),
    r'scanlator': PropertySchema(
      id: 46,
      name: r'scanlator',
      type: IsarType.string,
    ),
    r'silent': PropertySchema(
      id: 47,
      name: r'silent',
      type: IsarType.bool,
    ),
    r'sourceId': PropertySchema(
      id: 48,
      name: r'sourceId',
      type: IsarType.string,
    ),
    r'sourceIdIndex': PropertySchema(
      id: 49,
      name: r'sourceIdIndex',
      type: IsarType.string,
    ),
    r'state': PropertySchema(
      id: 50,
      name: r'state',
      type: IsarType.string,
      enumMap: _UpdatestateEnumValueMap,
    ),
    r'stateDateIndex': PropertySchema(
      id: 51,
      name: r'stateDateIndex',
      type: IsarType.string,
      enumMap: _UpdatestateDateIndexEnumValueMap,
    ),
    r'stateIndex': PropertySchema(
      id: 52,
      name: r'stateIndex',
      type: IsarType.string,
      enumMap: _UpdatestateIndexEnumValueMap,
    ),
    r'summary': PropertySchema(
      id: 53,
      name: r'summary',
      type: IsarType.string,
    ),
    r'tags': PropertySchema(
      id: 54,
      name: r'tags',
      type: IsarType.stringList,
    ),
    r'updatedAt': PropertySchema(
      id: 55,
      name: r'updatedAt',
      type: IsarType.long,
    ),
    r'url': PropertySchema(
      id: 56,
      name: r'url',
      type: IsarType.string,
    ),
    r'videoDuration': PropertySchema(
      id: 57,
      name: r'videoDuration',
      type: IsarType.long,
    ),
    r'videoQualities': PropertySchema(
      id: 58,
      name: r'videoQualities',
      type: IsarType.stringList,
    )
  },
  estimateSize: _updateEstimateSize,
  serialize: _updateSerialize,
  deserialize: _updateDeserialize,
  deserializeProp: _updateDeserializeProp,
  idName: r'id',
  indexes: {
    r'mangaIdIndex': IndexSchema(
      id: 5899444865427616617,
      name: r'mangaIdIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'mangaIdIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'chapterIdIndex': IndexSchema(
      id: 4785143513443022250,
      name: r'chapterIdIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'chapterIdIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'dateIndex': IndexSchema(
      id: 5202930406488400928,
      name: r'dateIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'dateIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'discoveredAtIndex': IndexSchema(
      id: 8628031655317363388,
      name: r'discoveredAtIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'discoveredAtIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'sourceIdIndex': IndexSchema(
      id: -5064764038557396038,
      name: r'sourceIdIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'sourceIdIndex',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    ),
    r'mediaTypeIndex': IndexSchema(
      id: -6065007409749526479,
      name: r'mediaTypeIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'mediaTypeIndex',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    ),
    r'stateIndex': IndexSchema(
      id: -5841096252777046523,
      name: r'stateIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'stateIndex',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    ),
    r'isReadIndex': IndexSchema(
      id: 5144447292709996813,
      name: r'isReadIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'isReadIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'isDownloadedIndex': IndexSchema(
      id: -538162128458274253,
      name: r'isDownloadedIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'isDownloadedIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'isBookmarkedIndex': IndexSchema(
      id: -3049755408240381087,
      name: r'isBookmarkedIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'isBookmarkedIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'isSeenIndex': IndexSchema(
      id: 3804348488679508904,
      name: r'isSeenIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'isSeenIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'isSyncedIndex': IndexSchema(
      id: 1660844896330617870,
      name: r'isSyncedIndex',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'isSyncedIndex',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'mangaDateIndex_date': IndexSchema(
      id: 6144680258294679458,
      name: r'mangaDateIndex_date',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'mangaDateIndex',
          type: IndexType.value,
          caseSensitive: false,
        ),
        IndexPropertySchema(
          name: r'date',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'stateDateIndex_date': IndexSchema(
      id: -6247464575262019209,
      name: r'stateDateIndex_date',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'stateDateIndex',
          type: IndexType.hash,
          caseSensitive: true,
        ),
        IndexPropertySchema(
          name: r'date',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'mangaChapterIndex_chapterId': IndexSchema(
      id: -9078075847608823625,
      name: r'mangaChapterIndex_chapterId',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'mangaChapterIndex',
          type: IndexType.value,
          caseSensitive: false,
        ),
        IndexPropertySchema(
          name: r'chapterId',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    )
  },
  links: {},
  embeddedSchemas: {},
  getId: _updateGetId,
  getLinks: _updateGetLinks,
  attach: _updateAttach,
  version: '3.1.0+1',
);

int _updateEstimateSize(
  Update object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  {
    final value = object.chapterIdString;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.chapterName;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.chapterNumber;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.deviceId;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.language;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.mangaCover;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.mangaIdString;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.mangaTitle;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.mediaType;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.mediaTypeIndex;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.metadataJson;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.note;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final list = object.previewUrls;
    if (list != null) {
      bytesCount += 3 + list.length * 3;
      {
        for (var i = 0; i < list.length; i++) {
          final value = list[i];
          bytesCount += value.length * 3;
        }
      }
    }
  }
  {
    final value = object.scanlator;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.sourceId;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.sourceIdIndex;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.state;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.stateDateIndex;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.stateIndex;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.summary;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final list = object.tags;
    if (list != null) {
      bytesCount += 3 + list.length * 3;
      {
        for (var i = 0; i < list.length; i++) {
          final value = list[i];
          bytesCount += value.length * 3;
        }
      }
    }
  }
  {
    final value = object.url;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final list = object.videoQualities;
    if (list != null) {
      bytesCount += 3 + list.length * 3;
      {
        for (var i = 0; i < list.length; i++) {
          final value = list[i];
          bytesCount += value.length * 3;
        }
      }
    }
  }
  return bytesCount;
}

void _updateSerialize(
  Update object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeLong(offsets[0], object.categoryId);
  writer.writeLong(offsets[1], object.chapterId);
  writer.writeLong(offsets[2], object.chapterIdIndex);
  writer.writeString(offsets[3], object.chapterIdString);
  writer.writeString(offsets[4], object.chapterName);
  writer.writeString(offsets[5], object.chapterNumber);
  writer.writeDouble(offsets[6], object.chapterNumberValue);
  writer.writeLong(offsets[7], object.date);
  writer.writeLong(offsets[8], object.dateIndex);
  writer.writeString(offsets[9], object.deviceId);
  writer.writeLong(offsets[10], object.discoveredAt);
  writer.writeLong(offsets[11], object.discoveredAtIndex);
  writer.writeDouble(offsets[12], object.effectiveChapterNumber);
  writer.writeLong(offsets[13], object.fileSize);
  writer.writeLong(offsets[14], object.hashCode);
  writer.writeBool(offsets[15], object.isAnime);
  writer.writeBool(offsets[16], object.isBook);
  writer.writeBool(offsets[17], object.isBookmarked);
  writer.writeBool(offsets[18], object.isBookmarkedIndex);
  writer.writeBool(offsets[19], object.isDismissed);
  writer.writeBool(offsets[20], object.isDownloaded);
  writer.writeBool(offsets[21], object.isDownloadedIndex);
  writer.writeBool(offsets[22], object.isFresh);
  writer.writeBool(offsets[23], object.isManga);
  writer.writeBool(offsets[24], object.isRead);
  writer.writeBool(offsets[25], object.isReadIndex);
  writer.writeBool(offsets[26], object.isSeen);
  writer.writeBool(offsets[27], object.isSeenIndex);
  writer.writeBool(offsets[28], object.isSynced);
  writer.writeBool(offsets[29], object.isSyncedIndex);
  writer.writeString(offsets[30], object.language);
  writer.writeLong(offsets[31], object.lastSyncedAt);
  writer.writeLong(offsets[32], object.mangaChapterIndex);
  writer.writeString(offsets[33], object.mangaCover);
  writer.writeLong(offsets[34], object.mangaDateIndex);
  writer.writeLong(offsets[35], object.mangaId);
  writer.writeLong(offsets[36], object.mangaIdIndex);
  writer.writeString(offsets[37], object.mangaIdString);
  writer.writeString(offsets[38], object.mangaTitle);
  writer.writeString(offsets[39], object.mediaType?.name);
  writer.writeString(offsets[40], object.mediaTypeIndex?.name);
  writer.writeString(offsets[41], object.metadataJson);
  writer.writeString(offsets[42], object.note);
  writer.writeLong(offsets[43], object.pageCount);
  writer.writeStringList(offsets[44], object.previewUrls);
  writer.writeLong(offsets[45], object.revision);
  writer.writeString(offsets[46], object.scanlator);
  writer.writeBool(offsets[47], object.silent);
  writer.writeString(offsets[48], object.sourceId);
  writer.writeString(offsets[49], object.sourceIdIndex);
  writer.writeString(offsets[50], object.state?.name);
  writer.writeString(offsets[51], object.stateDateIndex?.name);
  writer.writeString(offsets[52], object.stateIndex?.name);
  writer.writeString(offsets[53], object.summary);
  writer.writeStringList(offsets[54], object.tags);
  writer.writeLong(offsets[55], object.updatedAt);
  writer.writeString(offsets[56], object.url);
  writer.writeLong(offsets[57], object.videoDuration);
  writer.writeStringList(offsets[58], object.videoQualities);
}

Update _updateDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = Update(
    categoryId: reader.readLongOrNull(offsets[0]),
    chapterId: reader.readLongOrNull(offsets[1]),
    chapterIdString: reader.readStringOrNull(offsets[3]),
    chapterName: reader.readStringOrNull(offsets[4]),
    chapterNumber: reader.readStringOrNull(offsets[5]),
    chapterNumberValue: reader.readDoubleOrNull(offsets[6]),
    date: reader.readLongOrNull(offsets[7]),
    deviceId: reader.readStringOrNull(offsets[9]),
    discoveredAt: reader.readLongOrNull(offsets[10]),
    fileSize: reader.readLongOrNull(offsets[13]),
    id: id,
    isAnime: reader.readBoolOrNull(offsets[15]),
    isBook: reader.readBoolOrNull(offsets[16]),
    isBookmarked: reader.readBoolOrNull(offsets[17]),
    isDismissed: reader.readBoolOrNull(offsets[19]),
    isDownloaded: reader.readBoolOrNull(offsets[20]),
    isManga: reader.readBoolOrNull(offsets[23]),
    isRead: reader.readBoolOrNull(offsets[24]),
    isSeen: reader.readBoolOrNull(offsets[26]),
    isSynced: reader.readBoolOrNull(offsets[28]),
    language: reader.readStringOrNull(offsets[30]),
    lastSyncedAt: reader.readLongOrNull(offsets[31]),
    mangaCover: reader.readStringOrNull(offsets[33]),
    mangaId: reader.readLongOrNull(offsets[35]),
    mangaIdString: reader.readStringOrNull(offsets[37]),
    mangaTitle: reader.readStringOrNull(offsets[38]),
    mediaType:
        _UpdatemediaTypeValueEnumMap[reader.readStringOrNull(offsets[39])],
    metadataJson: reader.readStringOrNull(offsets[41]),
    note: reader.readStringOrNull(offsets[42]),
    pageCount: reader.readLongOrNull(offsets[43]),
    previewUrls: reader.readStringList(offsets[44]),
    revision: reader.readLongOrNull(offsets[45]),
    scanlator: reader.readStringOrNull(offsets[46]),
    silent: reader.readBoolOrNull(offsets[47]),
    sourceId: reader.readStringOrNull(offsets[48]),
    state: _UpdatestateValueEnumMap[reader.readStringOrNull(offsets[50])],
    summary: reader.readStringOrNull(offsets[53]),
    tags: reader.readStringList(offsets[54]),
    updatedAt: reader.readLongOrNull(offsets[55]),
    url: reader.readStringOrNull(offsets[56]),
    videoDuration: reader.readLongOrNull(offsets[57]),
    videoQualities: reader.readStringList(offsets[58]),
  );
  return object;
}

P _updateDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readLongOrNull(offset)) as P;
    case 1:
      return (reader.readLongOrNull(offset)) as P;
    case 2:
      return (reader.readLongOrNull(offset)) as P;
    case 3:
      return (reader.readStringOrNull(offset)) as P;
    case 4:
      return (reader.readStringOrNull(offset)) as P;
    case 5:
      return (reader.readStringOrNull(offset)) as P;
    case 6:
      return (reader.readDoubleOrNull(offset)) as P;
    case 7:
      return (reader.readLongOrNull(offset)) as P;
    case 8:
      return (reader.readLongOrNull(offset)) as P;
    case 9:
      return (reader.readStringOrNull(offset)) as P;
    case 10:
      return (reader.readLongOrNull(offset)) as P;
    case 11:
      return (reader.readLongOrNull(offset)) as P;
    case 12:
      return (reader.readDouble(offset)) as P;
    case 13:
      return (reader.readLongOrNull(offset)) as P;
    case 14:
      return (reader.readLong(offset)) as P;
    case 15:
      return (reader.readBoolOrNull(offset)) as P;
    case 16:
      return (reader.readBoolOrNull(offset)) as P;
    case 17:
      return (reader.readBoolOrNull(offset)) as P;
    case 18:
      return (reader.readBool(offset)) as P;
    case 19:
      return (reader.readBoolOrNull(offset)) as P;
    case 20:
      return (reader.readBoolOrNull(offset)) as P;
    case 21:
      return (reader.readBool(offset)) as P;
    case 22:
      return (reader.readBool(offset)) as P;
    case 23:
      return (reader.readBoolOrNull(offset)) as P;
    case 24:
      return (reader.readBoolOrNull(offset)) as P;
    case 25:
      return (reader.readBool(offset)) as P;
    case 26:
      return (reader.readBoolOrNull(offset)) as P;
    case 27:
      return (reader.readBool(offset)) as P;
    case 28:
      return (reader.readBoolOrNull(offset)) as P;
    case 29:
      return (reader.readBool(offset)) as P;
    case 30:
      return (reader.readStringOrNull(offset)) as P;
    case 31:
      return (reader.readLongOrNull(offset)) as P;
    case 32:
      return (reader.readLongOrNull(offset)) as P;
    case 33:
      return (reader.readStringOrNull(offset)) as P;
    case 34:
      return (reader.readLongOrNull(offset)) as P;
    case 35:
      return (reader.readLongOrNull(offset)) as P;
    case 36:
      return (reader.readLongOrNull(offset)) as P;
    case 37:
      return (reader.readStringOrNull(offset)) as P;
    case 38:
      return (reader.readStringOrNull(offset)) as P;
    case 39:
      return (_UpdatemediaTypeValueEnumMap[reader.readStringOrNull(offset)])
          as P;
    case 40:
      return (_UpdatemediaTypeIndexValueEnumMap[
          reader.readStringOrNull(offset)]) as P;
    case 41:
      return (reader.readStringOrNull(offset)) as P;
    case 42:
      return (reader.readStringOrNull(offset)) as P;
    case 43:
      return (reader.readLongOrNull(offset)) as P;
    case 44:
      return (reader.readStringList(offset)) as P;
    case 45:
      return (reader.readLongOrNull(offset)) as P;
    case 46:
      return (reader.readStringOrNull(offset)) as P;
    case 47:
      return (reader.readBoolOrNull(offset)) as P;
    case 48:
      return (reader.readStringOrNull(offset)) as P;
    case 49:
      return (reader.readStringOrNull(offset)) as P;
    case 50:
      return (_UpdatestateValueEnumMap[reader.readStringOrNull(offset)]) as P;
    case 51:
      return (_UpdatestateDateIndexValueEnumMap[
          reader.readStringOrNull(offset)]) as P;
    case 52:
      return (_UpdatestateIndexValueEnumMap[reader.readStringOrNull(offset)])
          as P;
    case 53:
      return (reader.readStringOrNull(offset)) as P;
    case 54:
      return (reader.readStringList(offset)) as P;
    case 55:
      return (reader.readLongOrNull(offset)) as P;
    case 56:
      return (reader.readStringOrNull(offset)) as P;
    case 57:
      return (reader.readLongOrNull(offset)) as P;
    case 58:
      return (reader.readStringList(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

const _UpdatemediaTypeEnumValueMap = {
  r'manga': r'manga',
  r'anime': r'anime',
  r'epub': r'epub',
  r'pdf': r'pdf',
};
const _UpdatemediaTypeValueEnumMap = {
  r'manga': UpdateMediaType.manga,
  r'anime': UpdateMediaType.anime,
  r'epub': UpdateMediaType.epub,
  r'pdf': UpdateMediaType.pdf,
};
const _UpdatemediaTypeIndexEnumValueMap = {
  r'manga': r'manga',
  r'anime': r'anime',
  r'epub': r'epub',
  r'pdf': r'pdf',
};
const _UpdatemediaTypeIndexValueEnumMap = {
  r'manga': UpdateMediaType.manga,
  r'anime': UpdateMediaType.anime,
  r'epub': UpdateMediaType.epub,
  r'pdf': UpdateMediaType.pdf,
};
const _UpdatestateEnumValueMap = {
  r'unread': r'unread',
  r'read': r'read',
  r'downloaded': r'downloaded',
  r'dismissed': r'dismissed',
  r'bookmarked': r'bookmarked',
  r'ignored': r'ignored',
};
const _UpdatestateValueEnumMap = {
  r'unread': UpdateState.unread,
  r'read': UpdateState.read,
  r'downloaded': UpdateState.downloaded,
  r'dismissed': UpdateState.dismissed,
  r'bookmarked': UpdateState.bookmarked,
  r'ignored': UpdateState.ignored,
};
const _UpdatestateDateIndexEnumValueMap = {
  r'unread': r'unread',
  r'read': r'read',
  r'downloaded': r'downloaded',
  r'dismissed': r'dismissed',
  r'bookmarked': r'bookmarked',
  r'ignored': r'ignored',
};
const _UpdatestateDateIndexValueEnumMap = {
  r'unread': UpdateState.unread,
  r'read': UpdateState.read,
  r'downloaded': UpdateState.downloaded,
  r'dismissed': UpdateState.dismissed,
  r'bookmarked': UpdateState.bookmarked,
  r'ignored': UpdateState.ignored,
};
const _UpdatestateIndexEnumValueMap = {
  r'unread': r'unread',
  r'read': r'read',
  r'downloaded': r'downloaded',
  r'dismissed': r'dismissed',
  r'bookmarked': r'bookmarked',
  r'ignored': r'ignored',
};
const _UpdatestateIndexValueEnumMap = {
  r'unread': UpdateState.unread,
  r'read': UpdateState.read,
  r'downloaded': UpdateState.downloaded,
  r'dismissed': UpdateState.dismissed,
  r'bookmarked': UpdateState.bookmarked,
  r'ignored': UpdateState.ignored,
};

Id _updateGetId(Update object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _updateGetLinks(Update object) {
  return [];
}

void _updateAttach(IsarCollection<dynamic> col, Id id, Update object) {
  object.id = id;
}

extension UpdateQueryWhereSort on QueryBuilder<Update, Update, QWhere> {
  QueryBuilder<Update, Update, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyMangaIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'mangaIdIndex'),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyChapterIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'chapterIdIndex'),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyDateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'dateIndex'),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyDiscoveredAtIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'discoveredAtIndex'),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyIsReadIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'isReadIndex'),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyIsDownloadedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'isDownloadedIndex'),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyIsBookmarkedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'isBookmarkedIndex'),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyIsSeenIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'isSeenIndex'),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyIsSyncedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'isSyncedIndex'),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyMangaDateIndexDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'mangaDateIndex_date'),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhere> anyMangaChapterIndexChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'mangaChapterIndex_chapterId'),
      );
    });
  }
}

extension UpdateQueryWhere on QueryBuilder<Update, Update, QWhereClause> {
  QueryBuilder<Update, Update, QAfterWhereClause> idEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> idNotEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> idGreaterThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> idLessThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaIdIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaIdIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaIdIndexEqualTo(
      int? mangaIdIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaIdIndex',
        value: [mangaIdIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaIdIndexNotEqualTo(
      int? mangaIdIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaIdIndex',
              lower: [],
              upper: [mangaIdIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaIdIndex',
              lower: [mangaIdIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaIdIndex',
              lower: [mangaIdIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaIdIndex',
              lower: [],
              upper: [mangaIdIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaIdIndexGreaterThan(
    int? mangaIdIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaIdIndex',
        lower: [mangaIdIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaIdIndexLessThan(
    int? mangaIdIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaIdIndex',
        lower: [],
        upper: [mangaIdIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaIdIndexBetween(
    int? lowerMangaIdIndex,
    int? upperMangaIdIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaIdIndex',
        lower: [lowerMangaIdIndex],
        includeLower: includeLower,
        upper: [upperMangaIdIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> chapterIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'chapterIdIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> chapterIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'chapterIdIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> chapterIdIndexEqualTo(
      int? chapterIdIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'chapterIdIndex',
        value: [chapterIdIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> chapterIdIndexNotEqualTo(
      int? chapterIdIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'chapterIdIndex',
              lower: [],
              upper: [chapterIdIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'chapterIdIndex',
              lower: [chapterIdIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'chapterIdIndex',
              lower: [chapterIdIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'chapterIdIndex',
              lower: [],
              upper: [chapterIdIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> chapterIdIndexGreaterThan(
    int? chapterIdIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'chapterIdIndex',
        lower: [chapterIdIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> chapterIdIndexLessThan(
    int? chapterIdIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'chapterIdIndex',
        lower: [],
        upper: [chapterIdIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> chapterIdIndexBetween(
    int? lowerChapterIdIndex,
    int? upperChapterIdIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'chapterIdIndex',
        lower: [lowerChapterIdIndex],
        includeLower: includeLower,
        upper: [upperChapterIdIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> dateIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'dateIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> dateIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'dateIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> dateIndexEqualTo(
      int? dateIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'dateIndex',
        value: [dateIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> dateIndexNotEqualTo(
      int? dateIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'dateIndex',
              lower: [],
              upper: [dateIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'dateIndex',
              lower: [dateIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'dateIndex',
              lower: [dateIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'dateIndex',
              lower: [],
              upper: [dateIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> dateIndexGreaterThan(
    int? dateIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'dateIndex',
        lower: [dateIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> dateIndexLessThan(
    int? dateIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'dateIndex',
        lower: [],
        upper: [dateIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> dateIndexBetween(
    int? lowerDateIndex,
    int? upperDateIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'dateIndex',
        lower: [lowerDateIndex],
        includeLower: includeLower,
        upper: [upperDateIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> discoveredAtIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'discoveredAtIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> discoveredAtIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'discoveredAtIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> discoveredAtIndexEqualTo(
      int? discoveredAtIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'discoveredAtIndex',
        value: [discoveredAtIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> discoveredAtIndexNotEqualTo(
      int? discoveredAtIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'discoveredAtIndex',
              lower: [],
              upper: [discoveredAtIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'discoveredAtIndex',
              lower: [discoveredAtIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'discoveredAtIndex',
              lower: [discoveredAtIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'discoveredAtIndex',
              lower: [],
              upper: [discoveredAtIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> discoveredAtIndexGreaterThan(
    int? discoveredAtIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'discoveredAtIndex',
        lower: [discoveredAtIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> discoveredAtIndexLessThan(
    int? discoveredAtIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'discoveredAtIndex',
        lower: [],
        upper: [discoveredAtIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> discoveredAtIndexBetween(
    int? lowerDiscoveredAtIndex,
    int? upperDiscoveredAtIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'discoveredAtIndex',
        lower: [lowerDiscoveredAtIndex],
        includeLower: includeLower,
        upper: [upperDiscoveredAtIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> sourceIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'sourceIdIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> sourceIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'sourceIdIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> sourceIdIndexEqualTo(
      String? sourceIdIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'sourceIdIndex',
        value: [sourceIdIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> sourceIdIndexNotEqualTo(
      String? sourceIdIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sourceIdIndex',
              lower: [],
              upper: [sourceIdIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sourceIdIndex',
              lower: [sourceIdIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sourceIdIndex',
              lower: [sourceIdIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sourceIdIndex',
              lower: [],
              upper: [sourceIdIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mediaTypeIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mediaTypeIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mediaTypeIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mediaTypeIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mediaTypeIndexEqualTo(
      UpdateMediaType? mediaTypeIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mediaTypeIndex',
        value: [mediaTypeIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mediaTypeIndexNotEqualTo(
      UpdateMediaType? mediaTypeIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mediaTypeIndex',
              lower: [],
              upper: [mediaTypeIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mediaTypeIndex',
              lower: [mediaTypeIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mediaTypeIndex',
              lower: [mediaTypeIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mediaTypeIndex',
              lower: [],
              upper: [mediaTypeIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> stateIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'stateIndex',
        value: [null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> stateIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'stateIndex',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> stateIndexEqualTo(
      UpdateState? stateIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'stateIndex',
        value: [stateIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> stateIndexNotEqualTo(
      UpdateState? stateIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateIndex',
              lower: [],
              upper: [stateIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateIndex',
              lower: [stateIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateIndex',
              lower: [stateIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateIndex',
              lower: [],
              upper: [stateIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> isReadIndexEqualTo(
      bool isReadIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'isReadIndex',
        value: [isReadIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> isReadIndexNotEqualTo(
      bool isReadIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isReadIndex',
              lower: [],
              upper: [isReadIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isReadIndex',
              lower: [isReadIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isReadIndex',
              lower: [isReadIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isReadIndex',
              lower: [],
              upper: [isReadIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> isDownloadedIndexEqualTo(
      bool isDownloadedIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'isDownloadedIndex',
        value: [isDownloadedIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> isDownloadedIndexNotEqualTo(
      bool isDownloadedIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDownloadedIndex',
              lower: [],
              upper: [isDownloadedIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDownloadedIndex',
              lower: [isDownloadedIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDownloadedIndex',
              lower: [isDownloadedIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDownloadedIndex',
              lower: [],
              upper: [isDownloadedIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> isBookmarkedIndexEqualTo(
      bool isBookmarkedIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'isBookmarkedIndex',
        value: [isBookmarkedIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> isBookmarkedIndexNotEqualTo(
      bool isBookmarkedIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isBookmarkedIndex',
              lower: [],
              upper: [isBookmarkedIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isBookmarkedIndex',
              lower: [isBookmarkedIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isBookmarkedIndex',
              lower: [isBookmarkedIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isBookmarkedIndex',
              lower: [],
              upper: [isBookmarkedIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> isSeenIndexEqualTo(
      bool isSeenIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'isSeenIndex',
        value: [isSeenIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> isSeenIndexNotEqualTo(
      bool isSeenIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSeenIndex',
              lower: [],
              upper: [isSeenIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSeenIndex',
              lower: [isSeenIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSeenIndex',
              lower: [isSeenIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSeenIndex',
              lower: [],
              upper: [isSeenIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> isSyncedIndexEqualTo(
      bool isSyncedIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'isSyncedIndex',
        value: [isSyncedIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> isSyncedIndexNotEqualTo(
      bool isSyncedIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSyncedIndex',
              lower: [],
              upper: [isSyncedIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSyncedIndex',
              lower: [isSyncedIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSyncedIndex',
              lower: [isSyncedIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isSyncedIndex',
              lower: [],
              upper: [isSyncedIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaDateIndexIsNullAnyDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaDateIndex_date',
        value: [null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaDateIndexIsNotNullAnyDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaDateIndex_date',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaDateIndexEqualToAnyDate(
      int? mangaDateIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaDateIndex_date',
        value: [mangaDateIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaDateIndexNotEqualToAnyDate(int? mangaDateIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaDateIndex_date',
              lower: [],
              upper: [mangaDateIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaDateIndex_date',
              lower: [mangaDateIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaDateIndex_date',
              lower: [mangaDateIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaDateIndex_date',
              lower: [],
              upper: [mangaDateIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaDateIndexGreaterThanAnyDate(
    int? mangaDateIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaDateIndex_date',
        lower: [mangaDateIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaDateIndexLessThanAnyDate(
    int? mangaDateIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaDateIndex_date',
        lower: [],
        upper: [mangaDateIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaDateIndexBetweenAnyDate(
    int? lowerMangaDateIndex,
    int? upperMangaDateIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaDateIndex_date',
        lower: [lowerMangaDateIndex],
        includeLower: includeLower,
        upper: [upperMangaDateIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaDateIndexEqualToDateIsNull(int? mangaDateIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaDateIndex_date',
        value: [mangaDateIndex, null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaDateIndexEqualToDateIsNotNull(int? mangaDateIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaDateIndex_date',
        lower: [mangaDateIndex, null],
        includeLower: false,
        upper: [
          mangaDateIndex,
        ],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> mangaDateIndexDateEqualTo(
      int? mangaDateIndex, int? date) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaDateIndex_date',
        value: [mangaDateIndex, date],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaDateIndexEqualToDateNotEqualTo(int? mangaDateIndex, int? date) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaDateIndex_date',
              lower: [mangaDateIndex],
              upper: [mangaDateIndex, date],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaDateIndex_date',
              lower: [mangaDateIndex, date],
              includeLower: false,
              upper: [mangaDateIndex],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaDateIndex_date',
              lower: [mangaDateIndex, date],
              includeLower: false,
              upper: [mangaDateIndex],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaDateIndex_date',
              lower: [mangaDateIndex],
              upper: [mangaDateIndex, date],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaDateIndexEqualToDateGreaterThan(
    int? mangaDateIndex,
    int? date, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaDateIndex_date',
        lower: [mangaDateIndex, date],
        includeLower: include,
        upper: [mangaDateIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaDateIndexEqualToDateLessThan(
    int? mangaDateIndex,
    int? date, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaDateIndex_date',
        lower: [mangaDateIndex],
        upper: [mangaDateIndex, date],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaDateIndexEqualToDateBetween(
    int? mangaDateIndex,
    int? lowerDate,
    int? upperDate, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaDateIndex_date',
        lower: [mangaDateIndex, lowerDate],
        includeLower: includeLower,
        upper: [mangaDateIndex, upperDate],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      stateDateIndexIsNullAnyDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'stateDateIndex_date',
        value: [null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      stateDateIndexIsNotNullAnyDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'stateDateIndex_date',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> stateDateIndexEqualToAnyDate(
      UpdateState? stateDateIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'stateDateIndex_date',
        value: [stateDateIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      stateDateIndexNotEqualToAnyDate(UpdateState? stateDateIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateDateIndex_date',
              lower: [],
              upper: [stateDateIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateDateIndex_date',
              lower: [stateDateIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateDateIndex_date',
              lower: [stateDateIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateDateIndex_date',
              lower: [],
              upper: [stateDateIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      stateDateIndexEqualToDateIsNull(UpdateState? stateDateIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'stateDateIndex_date',
        value: [stateDateIndex, null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      stateDateIndexEqualToDateIsNotNull(UpdateState? stateDateIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'stateDateIndex_date',
        lower: [stateDateIndex, null],
        includeLower: false,
        upper: [
          stateDateIndex,
        ],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause> stateDateIndexDateEqualTo(
      UpdateState? stateDateIndex, int? date) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'stateDateIndex_date',
        value: [stateDateIndex, date],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      stateDateIndexEqualToDateNotEqualTo(
          UpdateState? stateDateIndex, int? date) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateDateIndex_date',
              lower: [stateDateIndex],
              upper: [stateDateIndex, date],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateDateIndex_date',
              lower: [stateDateIndex, date],
              includeLower: false,
              upper: [stateDateIndex],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateDateIndex_date',
              lower: [stateDateIndex, date],
              includeLower: false,
              upper: [stateDateIndex],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'stateDateIndex_date',
              lower: [stateDateIndex],
              upper: [stateDateIndex, date],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      stateDateIndexEqualToDateGreaterThan(
    UpdateState? stateDateIndex,
    int? date, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'stateDateIndex_date',
        lower: [stateDateIndex, date],
        includeLower: include,
        upper: [stateDateIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      stateDateIndexEqualToDateLessThan(
    UpdateState? stateDateIndex,
    int? date, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'stateDateIndex_date',
        lower: [stateDateIndex],
        upper: [stateDateIndex, date],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      stateDateIndexEqualToDateBetween(
    UpdateState? stateDateIndex,
    int? lowerDate,
    int? upperDate, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'stateDateIndex_date',
        lower: [stateDateIndex, lowerDate],
        includeLower: includeLower,
        upper: [stateDateIndex, upperDate],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexIsNullAnyChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaChapterIndex_chapterId',
        value: [null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexIsNotNullAnyChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [null],
        includeLower: false,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexEqualToAnyChapterId(int? mangaChapterIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaChapterIndex_chapterId',
        value: [mangaChapterIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexNotEqualToAnyChapterId(int? mangaChapterIndex) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [],
              upper: [mangaChapterIndex],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [],
              upper: [mangaChapterIndex],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexGreaterThanAnyChapterId(
    int? mangaChapterIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [mangaChapterIndex],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexLessThanAnyChapterId(
    int? mangaChapterIndex, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [],
        upper: [mangaChapterIndex],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexBetweenAnyChapterId(
    int? lowerMangaChapterIndex,
    int? upperMangaChapterIndex, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [lowerMangaChapterIndex],
        includeLower: includeLower,
        upper: [upperMangaChapterIndex],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdIsNull(int? mangaChapterIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaChapterIndex_chapterId',
        value: [mangaChapterIndex, null],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdIsNotNull(int? mangaChapterIndex) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [mangaChapterIndex, null],
        includeLower: false,
        upper: [
          mangaChapterIndex,
        ],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexChapterIdEqualTo(
          int? mangaChapterIndex, int? chapterId) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'mangaChapterIndex_chapterId',
        value: [mangaChapterIndex, chapterId],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdNotEqualTo(
          int? mangaChapterIndex, int? chapterId) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex],
              upper: [mangaChapterIndex, chapterId],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex, chapterId],
              includeLower: false,
              upper: [mangaChapterIndex],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex, chapterId],
              includeLower: false,
              upper: [mangaChapterIndex],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'mangaChapterIndex_chapterId',
              lower: [mangaChapterIndex],
              upper: [mangaChapterIndex, chapterId],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdGreaterThan(
    int? mangaChapterIndex,
    int? chapterId, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [mangaChapterIndex, chapterId],
        includeLower: include,
        upper: [mangaChapterIndex],
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdLessThan(
    int? mangaChapterIndex,
    int? chapterId, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [mangaChapterIndex],
        upper: [mangaChapterIndex, chapterId],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterWhereClause>
      mangaChapterIndexEqualToChapterIdBetween(
    int? mangaChapterIndex,
    int? lowerChapterId,
    int? upperChapterId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'mangaChapterIndex_chapterId',
        lower: [mangaChapterIndex, lowerChapterId],
        includeLower: includeLower,
        upper: [mangaChapterIndex, upperChapterId],
        includeUpper: includeUpper,
      ));
    });
  }
}

extension UpdateQueryFilter on QueryBuilder<Update, Update, QFilterCondition> {
  QueryBuilder<Update, Update, QAfterFilterCondition> categoryIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'categoryId',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> categoryIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'categoryId',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> categoryIdEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'categoryId',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> categoryIdGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'categoryId',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> categoryIdLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'categoryId',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> categoryIdBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'categoryId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterId',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterId',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterId',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterId',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterId',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterIdIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      chapterIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterIdIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdIndexEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterIdIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdStringIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterIdString',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      chapterIdStringIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterIdString',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdStringEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      chapterIdStringGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdStringLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdStringBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterIdString',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdStringStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdStringEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdStringContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'chapterIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdStringMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'chapterIdString',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterIdStringIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterIdString',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      chapterIdStringIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'chapterIdString',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterName',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterName',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterName',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'chapterName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'chapterName',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterName',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNameIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'chapterName',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterNumber',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterNumber',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterNumber',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'chapterNumber',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'chapterNumber',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterNumber',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      chapterNumberIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'chapterNumber',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      chapterNumberValueIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'chapterNumberValue',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      chapterNumberValueIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'chapterNumberValue',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberValueEqualTo(
    double? value, {
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'chapterNumberValue',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      chapterNumberValueGreaterThan(
    double? value, {
    bool include = false,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'chapterNumberValue',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      chapterNumberValueLessThan(
    double? value, {
    bool include = false,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'chapterNumberValue',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> chapterNumberValueBetween(
    double? lower,
    double? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'chapterNumberValue',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'date',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'date',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'date',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'dateIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'dateIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateIndexEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'dateIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'dateIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'dateIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> dateIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'dateIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'deviceId',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'deviceId',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'deviceId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'deviceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'deviceId',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'deviceId',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> deviceIdIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'deviceId',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> discoveredAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'discoveredAt',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> discoveredAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'discoveredAt',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> discoveredAtEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'discoveredAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> discoveredAtGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'discoveredAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> discoveredAtLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'discoveredAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> discoveredAtBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'discoveredAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      discoveredAtIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'discoveredAtIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      discoveredAtIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'discoveredAtIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> discoveredAtIndexEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'discoveredAtIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      discoveredAtIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'discoveredAtIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> discoveredAtIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'discoveredAtIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> discoveredAtIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'discoveredAtIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      effectiveChapterNumberEqualTo(
    double value, {
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'effectiveChapterNumber',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      effectiveChapterNumberGreaterThan(
    double value, {
    bool include = false,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'effectiveChapterNumber',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      effectiveChapterNumberLessThan(
    double value, {
    bool include = false,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'effectiveChapterNumber',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      effectiveChapterNumberBetween(
    double lower,
    double upper, {
    bool includeLower = true,
    bool includeUpper = true,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'effectiveChapterNumber',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> fileSizeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'fileSize',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> fileSizeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'fileSize',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> fileSizeEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'fileSize',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> fileSizeGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'fileSize',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> fileSizeLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'fileSize',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> fileSizeBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'fileSize',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> hashCodeEqualTo(
      int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'hashCode',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> hashCodeGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'hashCode',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> hashCodeLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'hashCode',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> hashCodeBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'hashCode',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> idEqualTo(Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isAnimeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isAnime',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isAnimeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isAnime',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isAnimeEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isAnime',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isBookIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isBook',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isBookIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isBook',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isBookEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isBook',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isBookmarkedIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isBookmarked',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isBookmarkedIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isBookmarked',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isBookmarkedEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isBookmarked',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isBookmarkedIndexEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isBookmarkedIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isDismissedIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isDismissed',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isDismissedIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isDismissed',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isDismissedEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isDismissed',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isDownloadedIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isDownloaded',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isDownloadedIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isDownloaded',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isDownloadedEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isDownloaded',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isDownloadedIndexEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isDownloadedIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isFreshEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isFresh',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isMangaIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isManga',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isMangaIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isManga',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isMangaEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isManga',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isReadIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isRead',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isReadIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isRead',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isReadEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isRead',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isReadIndexEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isReadIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isSeenIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isSeen',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isSeenIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isSeen',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isSeenEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isSeen',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isSeenIndexEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isSeenIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isSyncedIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'isSynced',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isSyncedIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'isSynced',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isSyncedEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isSynced',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> isSyncedIndexEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isSyncedIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'language',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'language',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'language',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'language',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'language',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'language',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'language',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'language',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'language',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'language',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'language',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> languageIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'language',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> lastSyncedAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'lastSyncedAt',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> lastSyncedAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'lastSyncedAt',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> lastSyncedAtEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'lastSyncedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> lastSyncedAtGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'lastSyncedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> lastSyncedAtLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'lastSyncedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> lastSyncedAtBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'lastSyncedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      mangaChapterIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaChapterIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      mangaChapterIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaChapterIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaChapterIndexEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaChapterIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      mangaChapterIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaChapterIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaChapterIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaChapterIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaChapterIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaChapterIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaCover',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaCover',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaCover',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mangaCover',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mangaCover',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaCover',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaCoverIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mangaCover',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaDateIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaDateIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      mangaDateIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaDateIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaDateIndexEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaDateIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaDateIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaDateIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaDateIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaDateIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaDateIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaDateIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaId',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaId',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaId',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaId',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaId',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaIdIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaIdIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdIndexEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdIndexGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdIndexLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaIdIndex',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdIndexBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaIdIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaIdString',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaIdString',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaIdString',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mangaIdString',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mangaIdString',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaIdStringIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaIdString',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      mangaIdStringIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mangaIdString',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mangaTitle',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mangaTitle',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mangaTitle',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mangaTitle',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mangaTitle',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mangaTitle',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mangaTitleIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mangaTitle',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mediaType',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mediaType',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeEqualTo(
    UpdateMediaType? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeGreaterThan(
    UpdateMediaType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeLessThan(
    UpdateMediaType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeBetween(
    UpdateMediaType? lower,
    UpdateMediaType? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mediaType',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mediaType',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mediaType',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mediaType',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mediaType',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'mediaTypeIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      mediaTypeIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'mediaTypeIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIndexEqualTo(
    UpdateMediaType? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIndexGreaterThan(
    UpdateMediaType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIndexLessThan(
    UpdateMediaType? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIndexBetween(
    UpdateMediaType? lower,
    UpdateMediaType? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'mediaTypeIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIndexContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'mediaTypeIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'mediaTypeIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> mediaTypeIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'mediaTypeIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      mediaTypeIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'mediaTypeIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'metadataJson',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'metadataJson',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'metadataJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'metadataJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'metadataJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'metadataJson',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'metadataJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'metadataJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'metadataJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'metadataJson',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'metadataJson',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> metadataJsonIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'metadataJson',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'note',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'note',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'note',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteContains(String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'note',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'note',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> noteIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'note',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> pageCountIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'pageCount',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> pageCountIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'pageCount',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> pageCountEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'pageCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> pageCountGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'pageCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> pageCountLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'pageCount',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> pageCountBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'pageCount',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> previewUrlsIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'previewUrls',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> previewUrlsIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'previewUrls',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> previewUrlsElementEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'previewUrls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      previewUrlsElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'previewUrls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      previewUrlsElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'previewUrls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> previewUrlsElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'previewUrls',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      previewUrlsElementStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'previewUrls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      previewUrlsElementEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'previewUrls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      previewUrlsElementContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'previewUrls',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> previewUrlsElementMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'previewUrls',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      previewUrlsElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'previewUrls',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      previewUrlsElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'previewUrls',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> previewUrlsLengthEqualTo(
      int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'previewUrls',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> previewUrlsIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'previewUrls',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> previewUrlsIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'previewUrls',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> previewUrlsLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'previewUrls',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      previewUrlsLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'previewUrls',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> previewUrlsLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'previewUrls',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> revisionIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'revision',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> revisionIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'revision',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> revisionEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'revision',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> revisionGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'revision',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> revisionLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'revision',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> revisionBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'revision',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'scanlator',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'scanlator',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'scanlator',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'scanlator',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'scanlator',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'scanlator',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'scanlator',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'scanlator',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'scanlator',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'scanlator',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'scanlator',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> scanlatorIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'scanlator',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> silentIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'silent',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> silentIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'silent',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> silentEqualTo(
      bool? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'silent',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'sourceId',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'sourceId',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'sourceId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'sourceId',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'sourceId',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sourceId',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'sourceId',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'sourceIdIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'sourceIdIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'sourceIdIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'sourceIdIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'sourceIdIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> sourceIdIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sourceIdIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      sourceIdIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'sourceIdIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'state',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'state',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateEqualTo(
    UpdateState? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateGreaterThan(
    UpdateState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateLessThan(
    UpdateState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateBetween(
    UpdateState? lower,
    UpdateState? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'state',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'state',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'state',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'state',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'state',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateDateIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'stateDateIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      stateDateIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'stateDateIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateDateIndexEqualTo(
    UpdateState? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'stateDateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateDateIndexGreaterThan(
    UpdateState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'stateDateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateDateIndexLessThan(
    UpdateState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'stateDateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateDateIndexBetween(
    UpdateState? lower,
    UpdateState? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'stateDateIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateDateIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'stateDateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateDateIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'stateDateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateDateIndexContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'stateDateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateDateIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'stateDateIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateDateIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'stateDateIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      stateDateIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'stateDateIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'stateIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'stateIndex',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexEqualTo(
    UpdateState? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexGreaterThan(
    UpdateState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexLessThan(
    UpdateState? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexBetween(
    UpdateState? lower,
    UpdateState? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'stateIndex',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'stateIndex',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'stateIndex',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'stateIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> stateIndexIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'stateIndex',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'summary',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'summary',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'summary',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'summary',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'summary',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'summary',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'summary',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'summary',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'summary',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'summary',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'summary',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> summaryIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'summary',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'tags',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'tags',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsElementEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'tags',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsElementStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsElementEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsElementContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'tags',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsElementMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'tags',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'tags',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'tags',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsLengthEqualTo(
      int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> tagsLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'tags',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> updatedAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'updatedAt',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> updatedAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'updatedAt',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> updatedAtEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> updatedAtGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> updatedAtLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> updatedAtBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'updatedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'url',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'url',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'url',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlContains(String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'url',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlMatches(String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'url',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'url',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> urlIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'url',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> videoDurationIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'videoDuration',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> videoDurationIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'videoDuration',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> videoDurationEqualTo(
      int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'videoDuration',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> videoDurationGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'videoDuration',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> videoDurationLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'videoDuration',
        value: value,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> videoDurationBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'videoDuration',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> videoQualitiesIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'videoQualities',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'videoQualities',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesElementEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'videoQualities',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'videoQualities',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'videoQualities',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'videoQualities',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesElementStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'videoQualities',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesElementEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'videoQualities',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesElementContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'videoQualities',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesElementMatches(String pattern,
          {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'videoQualities',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'videoQualities',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'videoQualities',
        value: '',
      ));
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesLengthEqualTo(int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'videoQualities',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition> videoQualitiesIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'videoQualities',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'videoQualities',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'videoQualities',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'videoQualities',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<Update, Update, QAfterFilterCondition>
      videoQualitiesLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'videoQualities',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }
}

extension UpdateQueryObject on QueryBuilder<Update, Update, QFilterCondition> {}

extension UpdateQueryLinks on QueryBuilder<Update, Update, QFilterCondition> {}

extension UpdateQuerySortBy on QueryBuilder<Update, Update, QSortBy> {
  QueryBuilder<Update, Update, QAfterSortBy> sortByCategoryId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'categoryId', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByCategoryIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'categoryId', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterId', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterId', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterIdString() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdString', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterIdStringDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdString', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterName() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterName', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterNameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterName', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterNumber() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumber', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterNumberDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumber', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterNumberValue() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumberValue', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByChapterNumberValueDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumberValue', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByDateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByDateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'dateIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByDateIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'dateIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByDeviceId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deviceId', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByDeviceIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deviceId', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByDiscoveredAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'discoveredAt', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByDiscoveredAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'discoveredAt', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByDiscoveredAtIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'discoveredAtIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByDiscoveredAtIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'discoveredAtIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByEffectiveChapterNumber() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'effectiveChapterNumber', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy>
      sortByEffectiveChapterNumberDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'effectiveChapterNumber', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByFileSize() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileSize', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByFileSizeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileSize', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByHashCode() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hashCode', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByHashCodeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hashCode', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsAnime() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAnime', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsAnimeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAnime', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsBook() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBook', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsBookDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBook', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsBookmarked() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarked', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsBookmarkedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarked', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsBookmarkedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarkedIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsBookmarkedIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarkedIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsDismissed() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDismissed', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsDismissedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDismissed', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsDownloaded() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloaded', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsDownloadedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloaded', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsDownloadedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloadedIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsDownloadedIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloadedIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsFresh() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isFresh', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsFreshDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isFresh', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsManga() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isManga', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsMangaDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isManga', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsRead() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isRead', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsReadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isRead', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsReadIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isReadIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsReadIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isReadIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsSeen() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSeen', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsSeenDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSeen', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsSeenIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSeenIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsSeenIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSeenIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsSynced() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSynced', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsSyncedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSynced', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsSyncedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSyncedIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByIsSyncedIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSyncedIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByLanguage() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'language', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByLanguageDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'language', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByLastSyncedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastSyncedAt', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByLastSyncedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastSyncedAt', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaChapterIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaChapterIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaChapterIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaChapterIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaCover() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaCover', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaCoverDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaCover', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaDateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaDateIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaDateIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaDateIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaId', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaId', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaIdString() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdString', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaIdStringDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdString', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaTitle() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaTitle', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMangaTitleDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaTitle', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMediaType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaType', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMediaTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaType', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMediaTypeIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaTypeIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMediaTypeIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaTypeIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMetadataJson() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'metadataJson', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByMetadataJsonDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'metadataJson', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByNote() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByNoteDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByPageCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pageCount', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByPageCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pageCount', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByRevision() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'revision', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByRevisionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'revision', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByScanlator() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'scanlator', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByScanlatorDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'scanlator', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortBySilent() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'silent', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortBySilentDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'silent', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortBySourceId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceId', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortBySourceIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceId', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortBySourceIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortBySourceIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByState() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'state', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByStateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'state', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByStateDateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateDateIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByStateDateIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateDateIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByStateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByStateIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortBySummary() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'summary', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortBySummaryDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'summary', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByUrl() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'url', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByUrlDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'url', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByVideoDuration() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoDuration', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> sortByVideoDurationDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoDuration', Sort.desc);
    });
  }
}

extension UpdateQuerySortThenBy on QueryBuilder<Update, Update, QSortThenBy> {
  QueryBuilder<Update, Update, QAfterSortBy> thenByCategoryId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'categoryId', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByCategoryIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'categoryId', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterId', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterId', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterIdString() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdString', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterIdStringDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterIdString', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterName() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterName', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterNameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterName', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterNumber() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumber', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterNumberDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumber', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterNumberValue() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumberValue', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByChapterNumberValueDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'chapterNumberValue', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByDateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByDateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'dateIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByDateIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'dateIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByDeviceId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deviceId', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByDeviceIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'deviceId', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByDiscoveredAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'discoveredAt', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByDiscoveredAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'discoveredAt', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByDiscoveredAtIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'discoveredAtIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByDiscoveredAtIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'discoveredAtIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByEffectiveChapterNumber() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'effectiveChapterNumber', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy>
      thenByEffectiveChapterNumberDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'effectiveChapterNumber', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByFileSize() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileSize', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByFileSizeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fileSize', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByHashCode() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hashCode', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByHashCodeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hashCode', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsAnime() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAnime', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsAnimeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAnime', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsBook() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBook', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsBookDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBook', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsBookmarked() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarked', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsBookmarkedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarked', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsBookmarkedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarkedIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsBookmarkedIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarkedIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsDismissed() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDismissed', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsDismissedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDismissed', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsDownloaded() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloaded', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsDownloadedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloaded', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsDownloadedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloadedIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsDownloadedIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDownloadedIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsFresh() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isFresh', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsFreshDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isFresh', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsManga() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isManga', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsMangaDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isManga', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsRead() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isRead', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsReadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isRead', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsReadIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isReadIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsReadIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isReadIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsSeen() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSeen', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsSeenDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSeen', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsSeenIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSeenIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsSeenIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSeenIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsSynced() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSynced', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsSyncedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSynced', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsSyncedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSyncedIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByIsSyncedIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isSyncedIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByLanguage() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'language', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByLanguageDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'language', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByLastSyncedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastSyncedAt', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByLastSyncedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastSyncedAt', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaChapterIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaChapterIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaChapterIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaChapterIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaCover() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaCover', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaCoverDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaCover', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaDateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaDateIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaDateIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaDateIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaId', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaId', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaIdString() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdString', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaIdStringDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaIdString', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaTitle() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaTitle', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMangaTitleDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mangaTitle', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMediaType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaType', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMediaTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaType', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMediaTypeIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaTypeIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMediaTypeIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'mediaTypeIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMetadataJson() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'metadataJson', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByMetadataJsonDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'metadataJson', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByNote() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByNoteDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByPageCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pageCount', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByPageCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pageCount', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByRevision() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'revision', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByRevisionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'revision', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByScanlator() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'scanlator', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByScanlatorDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'scanlator', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenBySilent() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'silent', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenBySilentDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'silent', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenBySourceId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceId', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenBySourceIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceId', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenBySourceIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceIdIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenBySourceIdIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sourceIdIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByState() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'state', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByStateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'state', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByStateDateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateDateIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByStateDateIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateDateIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByStateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateIndex', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByStateIndexDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'stateIndex', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenBySummary() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'summary', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenBySummaryDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'summary', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByUrl() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'url', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByUrlDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'url', Sort.desc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByVideoDuration() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoDuration', Sort.asc);
    });
  }

  QueryBuilder<Update, Update, QAfterSortBy> thenByVideoDurationDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'videoDuration', Sort.desc);
    });
  }
}

extension UpdateQueryWhereDistinct on QueryBuilder<Update, Update, QDistinct> {
  QueryBuilder<Update, Update, QDistinct> distinctByCategoryId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'categoryId');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByChapterId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterId');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByChapterIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterIdIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByChapterIdString(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterIdString',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByChapterName(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterName', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByChapterNumber(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterNumber',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByChapterNumberValue() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'chapterNumberValue');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'date');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByDateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'dateIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByDeviceId(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'deviceId', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByDiscoveredAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'discoveredAt');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByDiscoveredAtIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'discoveredAtIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByEffectiveChapterNumber() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'effectiveChapterNumber');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByFileSize() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'fileSize');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByHashCode() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'hashCode');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsAnime() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isAnime');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsBook() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isBook');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsBookmarked() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isBookmarked');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsBookmarkedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isBookmarkedIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsDismissed() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isDismissed');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsDownloaded() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isDownloaded');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsDownloadedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isDownloadedIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsFresh() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isFresh');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsManga() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isManga');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsRead() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isRead');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsReadIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isReadIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsSeen() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isSeen');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsSeenIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isSeenIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsSynced() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isSynced');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByIsSyncedIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isSyncedIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByLanguage(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'language', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByLastSyncedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'lastSyncedAt');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByMangaChapterIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaChapterIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByMangaCover(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaCover', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByMangaDateIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaDateIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByMangaId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaId');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByMangaIdIndex() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaIdIndex');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByMangaIdString(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaIdString',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByMangaTitle(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mangaTitle', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByMediaType(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mediaType', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByMediaTypeIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'mediaTypeIndex',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByMetadataJson(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'metadataJson', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByNote(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'note', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByPageCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'pageCount');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByPreviewUrls() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'previewUrls');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByRevision() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'revision');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByScanlator(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'scanlator', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctBySilent() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'silent');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctBySourceId(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'sourceId', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctBySourceIdIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'sourceIdIndex',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByState(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'state', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByStateDateIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'stateDateIndex',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByStateIndex(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'stateIndex', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctBySummary(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'summary', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByTags() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'tags');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'updatedAt');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByUrl(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'url', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByVideoDuration() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'videoDuration');
    });
  }

  QueryBuilder<Update, Update, QDistinct> distinctByVideoQualities() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'videoQualities');
    });
  }
}

extension UpdateQueryProperty on QueryBuilder<Update, Update, QQueryProperty> {
  QueryBuilder<Update, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> categoryIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'categoryId');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> chapterIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterId');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> chapterIdIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterIdIndex');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> chapterIdStringProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterIdString');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> chapterNameProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterName');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> chapterNumberProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterNumber');
    });
  }

  QueryBuilder<Update, double?, QQueryOperations> chapterNumberValueProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'chapterNumberValue');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> dateProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'date');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> dateIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'dateIndex');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> deviceIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'deviceId');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> discoveredAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'discoveredAt');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> discoveredAtIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'discoveredAtIndex');
    });
  }

  QueryBuilder<Update, double, QQueryOperations>
      effectiveChapterNumberProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'effectiveChapterNumber');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> fileSizeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'fileSize');
    });
  }

  QueryBuilder<Update, int, QQueryOperations> hashCodeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'hashCode');
    });
  }

  QueryBuilder<Update, bool?, QQueryOperations> isAnimeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isAnime');
    });
  }

  QueryBuilder<Update, bool?, QQueryOperations> isBookProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isBook');
    });
  }

  QueryBuilder<Update, bool?, QQueryOperations> isBookmarkedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isBookmarked');
    });
  }

  QueryBuilder<Update, bool, QQueryOperations> isBookmarkedIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isBookmarkedIndex');
    });
  }

  QueryBuilder<Update, bool?, QQueryOperations> isDismissedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isDismissed');
    });
  }

  QueryBuilder<Update, bool?, QQueryOperations> isDownloadedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isDownloaded');
    });
  }

  QueryBuilder<Update, bool, QQueryOperations> isDownloadedIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isDownloadedIndex');
    });
  }

  QueryBuilder<Update, bool, QQueryOperations> isFreshProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isFresh');
    });
  }

  QueryBuilder<Update, bool?, QQueryOperations> isMangaProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isManga');
    });
  }

  QueryBuilder<Update, bool?, QQueryOperations> isReadProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isRead');
    });
  }

  QueryBuilder<Update, bool, QQueryOperations> isReadIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isReadIndex');
    });
  }

  QueryBuilder<Update, bool?, QQueryOperations> isSeenProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isSeen');
    });
  }

  QueryBuilder<Update, bool, QQueryOperations> isSeenIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isSeenIndex');
    });
  }

  QueryBuilder<Update, bool?, QQueryOperations> isSyncedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isSynced');
    });
  }

  QueryBuilder<Update, bool, QQueryOperations> isSyncedIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isSyncedIndex');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> languageProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'language');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> lastSyncedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'lastSyncedAt');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> mangaChapterIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaChapterIndex');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> mangaCoverProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaCover');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> mangaDateIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaDateIndex');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> mangaIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaId');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> mangaIdIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaIdIndex');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> mangaIdStringProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaIdString');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> mangaTitleProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mangaTitle');
    });
  }

  QueryBuilder<Update, UpdateMediaType?, QQueryOperations> mediaTypeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mediaType');
    });
  }

  QueryBuilder<Update, UpdateMediaType?, QQueryOperations>
      mediaTypeIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'mediaTypeIndex');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> metadataJsonProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'metadataJson');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> noteProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'note');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> pageCountProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'pageCount');
    });
  }

  QueryBuilder<Update, List<String>?, QQueryOperations> previewUrlsProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'previewUrls');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> revisionProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'revision');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> scanlatorProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'scanlator');
    });
  }

  QueryBuilder<Update, bool?, QQueryOperations> silentProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'silent');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> sourceIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'sourceId');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> sourceIdIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'sourceIdIndex');
    });
  }

  QueryBuilder<Update, UpdateState?, QQueryOperations> stateProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'state');
    });
  }

  QueryBuilder<Update, UpdateState?, QQueryOperations>
      stateDateIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'stateDateIndex');
    });
  }

  QueryBuilder<Update, UpdateState?, QQueryOperations> stateIndexProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'stateIndex');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> summaryProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'summary');
    });
  }

  QueryBuilder<Update, List<String>?, QQueryOperations> tagsProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'tags');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> updatedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'updatedAt');
    });
  }

  QueryBuilder<Update, String?, QQueryOperations> urlProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'url');
    });
  }

  QueryBuilder<Update, int?, QQueryOperations> videoDurationProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'videoDuration');
    });
  }

  QueryBuilder<Update, List<String>?, QQueryOperations>
      videoQualitiesProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'videoQualities');
    });
  }
}
