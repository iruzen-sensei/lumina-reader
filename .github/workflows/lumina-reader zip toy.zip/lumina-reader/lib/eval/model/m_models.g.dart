// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'm_models.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MManga _$MMangaFromJson(Map<String, dynamic> json) => MManga(
      name: json['name'] as String?,
      link: json['link'] as String?,
      imageUrl: json['imageUrl'] as String?,
      description: json['description'] as String?,
      author: json['author'] as String?,
      artist: json['artist'] as String?,
      status: json['status'] as String?,
      genre: json['genre'] as String?,
      categories: (json['categories'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
      isManga: json['isManga'] as bool?,
      isManhua: json['isManhua'] as bool?,
      isManhwa: json['isManhwa'] as bool?,
      isAnime: json['isAnime'] as bool?,
      isNsfw: json['isNsfw'] as bool?,
      source: json['source'] as String?,
    );

Map<String, dynamic> _$MMangaToJson(MManga instance) => <String, dynamic>{
      'name': instance.name,
      'link': instance.link,
      'imageUrl': instance.imageUrl,
      'description': instance.description,
      'author': instance.author,
      'artist': instance.artist,
      'status': instance.status,
      'genre': instance.genre,
      'categories': instance.categories,
      'isManga': instance.isManga,
      'isManhua': instance.isManhua,
      'isManhwa': instance.isManhwa,
      'isAnime': instance.isAnime,
      'isNsfw': instance.isNsfw,
      'source': instance.source,
    };

MChapter _$MChapterFromJson(Map<String, dynamic> json) => MChapter(
      name: json['name'] as String?,
      url: json['url'] as String?,
      dateUpload: json['dateUpload'] as String?,
      scanlator: json['scanlator'] as String?,
      mangaId: json['mangaId'] as String?,
      chapterNumber: json['chapterNumber'] as String?,
      volumeNumber: json['volumeNumber'] as String?,
      language: json['language'] as String?,
    );

Map<String, dynamic> _$MChapterToJson(MChapter instance) => <String, dynamic>{
      'name': instance.name,
      'url': instance.url,
      'dateUpload': instance.dateUpload,
      'scanlator': instance.scanlator,
      'mangaId': instance.mangaId,
      'chapterNumber': instance.chapterNumber,
      'volumeNumber': instance.volumeNumber,
      'language': instance.language,
    };

MPages _$MPagesFromJson(Map<String, dynamic> json) => MPages(
      images: (json['images'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      headers: (json['headers'] as List<dynamic>?)
          ?.map((e) => Map<String, String>.from(e as Map))
          .toList(),
      referer:
          (json['referer'] as List<dynamic>?)?.map((e) => e as String).toList(),
      source: json['source'] as String?,
    );

Map<String, dynamic> _$MPagesToJson(MPages instance) => <String, dynamic>{
      'images': instance.images,
      'headers': instance.headers,
      'referer': instance.referer,
      'source': instance.source,
    };

MSource _$MSourceFromJson(Map<String, dynamic> json) => MSource(
      id: json['id'] as String?,
      name: json['name'] as String?,
      lang: json['lang'] as String?,
      baseUrl: json['baseUrl'] as String?,
      apiUrl: json['apiUrl'] as String?,
      version: json['version'] as String?,
      iconUrl: json['iconUrl'] as String?,
      typeSource: json['typeSource'] as String?,
      isManga: json['isManga'] as bool?,
      isManhua: json['isManhua'] as bool?,
      isManhwa: json['isManhwa'] as bool?,
      isAnime: json['isAnime'] as bool?,
      isNsfw: json['isNsfw'] as bool?,
      hasCloudflare: json['hasCloudflare'] as bool?,
      headers: (json['headers'] as Map<String, dynamic>?)?.map(
        (k, e) => MapEntry(k, e as String),
      ),
      tags: (json['tags'] as List<dynamic>?)?.map((e) => e as String).toList(),
      isFullData: json['isFullData'] as bool?,
    );

Map<String, dynamic> _$MSourceToJson(MSource instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'lang': instance.lang,
      'baseUrl': instance.baseUrl,
      'apiUrl': instance.apiUrl,
      'version': instance.version,
      'iconUrl': instance.iconUrl,
      'typeSource': instance.typeSource,
      'isManga': instance.isManga,
      'isManhua': instance.isManhua,
      'isManhwa': instance.isManhwa,
      'isAnime': instance.isAnime,
      'isNsfw': instance.isNsfw,
      'hasCloudflare': instance.hasCloudflare,
      'headers': instance.headers,
      'tags': instance.tags,
      'isFullData': instance.isFullData,
    };

MVideo _$MVideoFromJson(Map<String, dynamic> json) => MVideo(
      url: json['url'] as String,
      originalUrl: json['originalUrl'] as String?,
      quality: json['quality'] as String?,
      title: json['title'] as String?,
      headers: (json['headers'] as Map<String, dynamic>?)?.map(
        (k, e) => MapEntry(k, e as String),
      ),
      parameters: json['parameters'] as Map<String, dynamic>?,
    );

Map<String, dynamic> _$MVideoToJson(MVideo instance) => <String, dynamic>{
      'url': instance.url,
      'originalUrl': instance.originalUrl,
      'quality': instance.quality,
      'title': instance.title,
      'headers': instance.headers,
      'parameters': instance.parameters,
    };
